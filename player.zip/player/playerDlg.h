﻿
// playerDlg.h: 头文件
//

#pragma once


// CplayerDlg 对话框
class CplayerDlg : public CDialogEx
{
// 构造
public:
	CplayerDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PLAYER_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	// 用户名
	CString name;
	// 攻击力
	int attack;
	// 防御力
	int defense;
	// 体力
	int hp;
	// 闪避率
	int miss;
	// 男
	BOOL male;
	// 女
	BOOL female;
	afx_msg void OnEnChangeattack();
	afx_msg void OnEnChangedefense();
	afx_msg void OnEnChangehp();
	afx_msg void OnEnChangemiss();
};
