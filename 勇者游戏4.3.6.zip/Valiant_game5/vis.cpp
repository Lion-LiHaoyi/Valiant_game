#include "vis.h"
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <mmsystem.h>
#include <shellapi.h>
#include <AFXCOM_.H>
#pragma comment(lib,"winmm.lib")

UINT DeviceID;
void Music(WCHAR* a)
{
	char str[128] = { 0 };
	int i = 0;
	char buf[128] = { 0 };
	MCI_OPEN_PARMS mciOpen;
	MCIERROR mciError;
	mciOpen.lpstrDeviceType = _T("mpegvideo");
	mciOpen.lpstrElementName = a;
	mciError = mciSendCommand(0, MCI_OPEN, MCI_OPEN_TYPE | MCI_OPEN_ELEMENT, (DWORD_PTR)&mciOpen);
	if (mciError)
	{
		return;
	}
	DeviceID = mciOpen.wDeviceID;
	MCI_PLAY_PARMS mciPlay;
	mciError = mciSendCommand(DeviceID, MCI_PLAY, 0, (DWORD_PTR)&mciPlay);
	if (mciError)
	{
		return;
	}
	return;
}
void NoMusic()
{
	MCI_GENERIC_PARMS mcistop;
	mciSendCommand(MCI_ALL_DEVICE_ID, MCI_CLOSE, MCI_WAIT, (DWORD_PTR)(LPMCI_GENERIC_PARMS)&mcistop);
}