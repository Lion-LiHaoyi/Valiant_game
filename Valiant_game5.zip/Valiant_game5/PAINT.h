#ifndef _PAINT_
#define _PAINT_

#include <windows.h>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <cstring>
#include <algorithm>

#define M_PI		3.14159265358979323846
using namespace std;

void RotateAnyAngle(HDC hdcDest,int placex,int placey,int SrcWidth,int SrcHeight,HDC hdcSrc,int nXOriginSrc,int nYOriginSrc,float Angle,bool Middle,COLORREF clrBack,bool Trans = true)
{
	if(!Angle)
	{
		if(Trans) TransparentBlt(hdcDest,placex,placey,SrcWidth,SrcHeight,hdcSrc,0,0,SrcWidth,SrcHeight,clrBack);
		else BitBlt(hdcDest,placex,placey,SrcWidth,SrcHeight,hdcSrc,0,0,SRCCOPY);

		return;
	}

	HDC destDC = CreateCompatibleDC(NULL);

	float cosine = (float)cos(Angle / 180 * M_PI);
	float sine = (float)sin(Angle / 180 * M_PI);
	int x1 = (int)(SrcHeight * sine);
	int y1 = (int)(SrcHeight * cosine);
	int x2 = (int)(SrcWidth * cosine + SrcHeight * sine);
	int y2 = (int)(SrcHeight * cosine - SrcWidth * sine);
	int x3 = (int)(SrcWidth * cosine);
	int y3 = (int)(-SrcWidth * sine);
	int minx = min(0,min(x1,min(x2,x3)));
	int miny = min(0,min(y1,min(y2,y3)));
	int maxx = max(0,max(x1,max(x2,x3)));
	int maxy = max(0,max(y1,max(y2,y3)));
	int w = maxx - minx;
	int h = maxy - miny;

	if(Middle)
	{
		placex -= (w - SrcWidth) / 2;  placey -= (h - SrcHeight) / 2;
	}

	HBITMAP hbmResult = CreateCompatibleBitmap(GetDC(NULL),w,h);
	HBITMAP hbmOldDest = (HBITMAP)::SelectObject(destDC,hbmResult);

	if(clrBack != RGB(0,0,0))
	{
		HBRUSH hbrBack = CreateSolidBrush(clrBack);
		HBRUSH hbrOld = (HBRUSH)::SelectObject(destDC,hbrBack);
		PatBlt(destDC,0,0,w,h,PATCOPY);

		DeleteObject(::SelectObject(destDC,hbrOld));
		DeleteObject(hbrBack);
		DeleteObject(hbrOld);
	}

	SetGraphicsMode(destDC,GM_ADVANCED);
	XFORM xform;
	xform.eM11 = cosine;
	xform.eM12 = -sine;
	xform.eM21 = sine;
	xform.eM22 = cosine;
	xform.eDx = (float)-minx;
	xform.eDy = (float)-miny;
	SetWorldTransform(destDC,&xform);

	BitBlt(destDC,0,0,SrcWidth,SrcHeight,hdcSrc,0,0,SRCCOPY);

	DeleteObject(hbmOldDest);
	DeleteObject(destDC);

	SelectObject(hdcSrc,hbmResult);
	DeleteObject(hbmResult);

	if(Trans) TransparentBlt(hdcDest,placex,placey,w,h,hdcSrc,0,0,w,h,clrBack);
	else BitBlt(hdcDest,placex,placey,w,h,hdcSrc,0,0,SRCCOPY);
}

void RotateAnyAngle(HDC hdcDest,POINT &place,POINT &WAH,HDC hdcSrc,int nXOriginSrc,int nYOriginSrc,float Angle,bool Middle,COLORREF clrBack,bool Trans = true)
{
	if(!Angle)
	{
		if(Trans) TransparentBlt(hdcDest,place.x,place.y,WAH.x,WAH.y,hdcSrc,0,0,WAH.x,WAH.y,clrBack);
		else BitBlt(hdcDest,place.x,place.y,WAH.x,WAH.y,hdcSrc,0,0,SRCCOPY);

		return;
	}

	HDC destDC = CreateCompatibleDC(NULL);

	float cosine = (float)cos(Angle / 180 * M_PI);
	float sine = (float)sin(Angle / 180 * M_PI);
	int x1 = (int)(WAH.y * sine);
	int y1 = (int)(WAH.y * cosine);
	int x2 = (int)(WAH.x * cosine + WAH.y * sine);
	int y2 = (int)(WAH.y * cosine - WAH.x * sine);
	int x3 = (int)(WAH.x * cosine);
	int y3 = (int)(-WAH.x * sine);
	int minx = min(0,min(x1,min(x2,x3)));
	int miny = min(0,min(y1,min(y2,y3)));
	int maxx = max(0,max(x1,max(x2,x3)));
	int maxy = max(0,max(y1,max(y2,y3)));
	int w = maxx - minx;
	int h = maxy - miny;

	if(Middle)
	{
		place.x -= (w - WAH.x) / 2;  place.y -= (h - WAH.y) / 2;
	}

	HBITMAP hbmResult = CreateCompatibleBitmap(GetDC(NULL),w,h);
	HBITMAP hbmOldDest = (HBITMAP)::SelectObject(destDC,hbmResult);

	if(clrBack != RGB(0,0,0))
	{
		HBRUSH hbrBack = CreateSolidBrush(clrBack);
		HBRUSH hbrOld = (HBRUSH)::SelectObject(destDC,hbrBack);
		PatBlt(destDC,0,0,w,h,PATCOPY);

		DeleteObject(::SelectObject(destDC,hbrOld));
		DeleteObject(hbrBack);
		DeleteObject(hbrOld);
	}

	SetGraphicsMode(destDC,GM_ADVANCED);
	XFORM xform;
	xform.eM11 = cosine;
	xform.eM12 = -sine;
	xform.eM21 = sine;
	xform.eM22 = cosine;
	xform.eDx = (float)-minx;
	xform.eDy = (float)-miny;
	SetWorldTransform(destDC,&xform);

	BitBlt(destDC,0,0,WAH.x,WAH.y,hdcSrc,0,0,SRCCOPY);

	WAH.x = w; WAH.y = h;

	DeleteObject(hbmOldDest);
	DeleteObject(destDC);

	SelectObject(hdcSrc,hbmResult);
	DeleteObject(hbmResult);

	if(Trans) TransparentBlt(hdcDest,0,0,w,h,hdcSrc,0,0,w,h,clrBack);
	else BitBlt(hdcDest,0,0,w,h,hdcSrc,0,0,SRCCOPY);
}

void Char_Print(HDC hdcDest,int nXOriginDest,int nYOriginDest,int nWidthDest,int nHeightDest,HFONT hf,COLORREF crTransparent,const char* wanna_char)
{
	RECT rect;

	SetRect(&rect,nXOriginDest,nYOriginDest,nXOriginDest + nWidthDest,nYOriginDest + nHeightDest);

	int Last_Mode = SetBkMode(hdcDest,TRANSPARENT);
	COLORREF Last_Color = SetTextColor(hdcDest,crTransparent);

	SelectObject(hdcDest,hf);
	DrawText(hdcDest,wanna_char,-1,&rect,DT_NOCLIP);

	SetBkMode(hdcDest,Last_Mode);
	SetTextColor(hdcDest,Last_Color);

	return;
}

float Get_FPS()
{
	static float  fps = 0;
	static int    frameCount = 0;
	static float  currentTime = 0.0f;
	static float  lastTime = 0.0f;

	frameCount++;
	currentTime = clock()*0.001f;

	if(currentTime - lastTime > 1.0f)
	{
		fps = (float)frameCount / (currentTime - lastTime);
		lastTime = currentTime;
		frameCount = 0;
	}

	return fps;
}

#endif

#ifndef _BMPX_
#define _BMPX_

typedef class bmpx
{
	static BLENDFUNCTION bf;

private:

	HBITMAP Bmp;
	int Height,Width;
	int bTrans;

	bool Trans_Mode;

public:

	bmpx();
	bmpx(int width,int height);
	bmpx(const char* File_Name);
	~bmpx();

	void Change_Bmp(const char* File_Name);

	inline void SetTransMode(bool Mode);
	inline void SetbTrans(int btrans);

	void Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc);

	void Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float multiple = 1);
	void Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float Angle,bool Middle_Mode);

	void Alpha_Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float multiple = 1);
	void Alpha_Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float Angle,bool Middle_Mode);

	inline HBITMAP GetBitmap() const;
	inline int GetHeight() const;
	inline int GetWidth() const;
	inline int GetbTrans() const;
	inline bool GetTransMode() const;
}Bmpx;

BLENDFUNCTION bmpx::bf = { AC_SRC_OVER,0,255,0 };

bmpx::bmpx()
{
	bTrans = 255;
	Trans_Mode = true;
}

bmpx::bmpx(int width,int height)
{
	Bmp = CreateCompatibleBitmap(NULL,width,height);

	Width = width;
	Height = height;

	bTrans = 255;
	Trans_Mode = true;
}

bmpx::bmpx(const char* File_Name)
{
	Bmp = (HBITMAP)LoadImage(GetModuleHandle(0),File_Name,IMAGE_BITMAP,0,0,LR_LOADFROMFILE | LR_CREATEDIBSECTION);

	BITMAP temp; GetObject(Bmp,sizeof(BITMAP),&temp);

	Width = temp.bmWidth;
	Height = temp.bmHeight;

	bTrans = 255;
	Trans_Mode = true;
}

bmpx::~bmpx()
{
	if(Bmp != NULL) DeleteObject(Bmp);
}

void bmpx::Change_Bmp(const char* File_Name)
{
	if(Bmp != NULL) DeleteObject(Bmp);

	Bmp = (HBITMAP)LoadImage(GetModuleHandle(0),File_Name,IMAGE_BITMAP,0,0,LR_LOADFROMFILE | LR_CREATEDIBSECTION);

	BITMAP temp; GetObject(Bmp,sizeof(BITMAP),&temp);

	Width = temp.bmWidth;
	Height = temp.bmHeight;
}

void bmpx::SetbTrans(int btrans)
{
	bTrans = btrans;
}

void bmpx::SetTransMode(bool Mode)
{
	Trans_Mode = Mode;
}

void bmpx::Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc)
{
	SelectObject(hdcSrc,Bmp);
	BitBlt(hdcDest,x,y,Width,Height,hdcSrc,0,0,SRCCOPY);
}

void bmpx::Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float multiple)
{
	SelectObject(hdcSrc,Bmp);
	TransparentBlt(hdcDest,x,y,Width*multiple,Height*multiple,hdcSrc,0,0,Width,Height,clrBack);
}

void bmpx::Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float Angle,bool Middle_Mode)
{
	SelectObject(hdcSrc,Bmp);
	RotateAnyAngle(hdcDest,x,y,Width,Height,hdcSrc,0,0,Angle,Middle_Mode,clrBack,Trans_Mode);
}

void bmpx::Alpha_Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float multiple)
{
	SelectObject(hdcSrc,Bmp);

	bf.SourceConstantAlpha = bTrans;

	int WM = Width * multiple,HM = Height * multiple;

	if(!Trans_Mode)
	{
		AlphaBlend(hdcDest,x,y,WM,HM,hdcSrc,0,0,Width,Height,bf);  return;
	}

	HDC Tr_DC = CreateCompatibleDC(hdcDest);
	HBITMAP Tr_Bmp = CreateCompatibleBitmap(hdcDest,WM,HM);

	SelectObject(Tr_DC,Tr_Bmp); DeleteObject(Tr_Bmp);

	BitBlt(Tr_DC,0,0,WM,HM,hdcDest,x,y,SRCCOPY);
	TransparentBlt(Tr_DC,0,0,WM,HM,hdcSrc,0,0,Width,Height,clrBack);
	AlphaBlend(hdcDest,x,y,WM,HM,Tr_DC,0,0,WM,HM,bf);

	DeleteObject(Tr_DC);
}

void bmpx::Alpha_Print_Bmp(HDC hdcDest,int x,int y,HDC hdcSrc,COLORREF clrBack,float Angle,bool Middle_Mode)
{
	SelectObject(hdcSrc,Bmp);

	bf.SourceConstantAlpha = bTrans;

	int WM = Width * 2,HM = Height * 2;

	POINT Place = { 0,0 },wah = { Width,Height };

	HDC Tr_DC = CreateCompatibleDC(hdcDest);
	HBITMAP Tr_Bmp = CreateCompatibleBitmap(hdcDest,WM,HM);

	SelectObject(Tr_DC,Tr_Bmp); DeleteObject(Tr_Bmp);

	RotateAnyAngle(Tr_DC,Place,wah,hdcSrc,0,0,Angle,Middle_Mode,clrBack,false);


	HDC Dr_DC = CreateCompatibleDC(hdcDest);
	HBITMAP Dr_Bmp = CreateCompatibleBitmap(hdcDest,wah.x,wah.y);
	SelectObject(Dr_DC,Dr_Bmp); DeleteObject(Dr_Bmp);

	x += Place.x; y += Place.y;

	if(!Trans_Mode)
	{
		AlphaBlend(hdcDest,x,y,wah.x,wah.y,Tr_DC,0,0,wah.x,wah.y,bf);

		DeleteObject(Tr_DC); DeleteObject(Dr_DC);

		return;
	}

	BitBlt(Dr_DC,0,0,wah.x,wah.y,hdcDest,x,y,SRCCOPY);
	TransparentBlt(Dr_DC,0,0,wah.x,wah.y,Tr_DC,0,0,wah.x,wah.y,clrBack);
	AlphaBlend(hdcDest,x,y,wah.x,wah.y,Dr_DC,0,0,wah.x,wah.y,bf);

	DeleteObject(Tr_DC);
	DeleteObject(Dr_DC);
}

HBITMAP bmpx::GetBitmap() const
{
	return Bmp;
}

int bmpx::GetHeight() const
{
	return Height;
}

int bmpx::GetWidth() const
{
	return Width;
}

int bmpx::GetbTrans() const
{
	return bTrans;
}

bool bmpx::GetTransMode() const
{
	return Trans_Mode;
}

#endif
