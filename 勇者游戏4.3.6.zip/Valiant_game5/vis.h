#pragma once
void Music(WCHAR*);
void NoMusic();