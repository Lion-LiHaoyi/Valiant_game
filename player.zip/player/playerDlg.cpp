﻿
// playerDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "player.h"
#include "playerDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeattack();
	afx_msg void OnEnChangedefense();
	afx_msg void OnEnChangehp();
	afx_msg void OnEnChangemiss();
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
	ON_EN_CHANGE(IDC_attack,&CAboutDlg::OnEnChangeattack)
	ON_EN_CHANGE(IDC_defense,&CAboutDlg::OnEnChangedefense)
	ON_EN_CHANGE(IDC_hp,&CAboutDlg::OnEnChangehp)
	ON_EN_CHANGE(IDC_miss,&CAboutDlg::OnEnChangemiss)
END_MESSAGE_MAP()


// CplayerDlg 对话框



CplayerDlg::CplayerDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_PLAYER_DIALOG, pParent)
	,name(_T(""))
	,attack(70)
	,defense(50)
	,hp(120)
	,miss(10)
	,male(TRUE)
	,female(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CplayerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX,IDC_name,name);
	DDX_Text(pDX,IDC_attack,attack);
	DDX_Text(pDX,IDC_defense,defense);
	DDX_Text(pDX,IDC_hp,hp);
	DDX_Text(pDX,IDC_miss,miss);
	DDX_Radio(pDX,IDC_RADIO1,male);
	DDX_Radio(pDX,IDC_RADIO2,female);
}

BEGIN_MESSAGE_MAP(CplayerDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_attack,&CplayerDlg::OnEnChangeattack)
	ON_EN_CHANGE(IDC_defense,&CplayerDlg::OnEnChangedefense)
	ON_EN_CHANGE(IDC_hp,&CplayerDlg::OnEnChangehp)
	ON_EN_CHANGE(IDC_miss,&CplayerDlg::OnEnChangemiss)
END_MESSAGE_MAP()


// CplayerDlg 消息处理程序

BOOL CplayerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CplayerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CplayerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CplayerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CAboutDlg::OnEnChangeattack()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CAboutDlg::OnEnChangedefense()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CAboutDlg::OnEnChangehp()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CAboutDlg::OnEnChangemiss()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}




void CplayerDlg::OnEnChangeattack()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码

	int attack = GetDlgItemInt(IDC_attack),defense = GetDlgItemInt(IDC_defense),hp = GetDlgItemInt(IDC_hp),miss = GetDlgItemInt(IDC_miss);

	char str[100];
	sprintf_s(str,"Your attack is:%d",attack);
//	MessageBoxA(NULL,str,"",MB_OK);
	short a = check(0);
	if(a == -1)return;
	switch(a)
	{
		case 1:
			defense = (420-1.5*attack-hp-10*miss)/1.5;
			sprintf_s(str,"%d",defense);
			SetDlgItemText(IDC_defense,str);
		default:
			break;
	}
}



void CplayerDlg::OnEnChangedefense()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
	int attack = GetDlgItemInt(IDC_attack),defense = GetDlgItemInt(IDC_defense),hp = GetDlgItemInt(IDC_hp),miss = GetDlgItemInt(IDC_miss);

	char str[100];
	sprintf_s(str,"Your defense is:%d",defense);
	short a = check(1);
	if(a == -1)return;
}


void CplayerDlg::OnEnChangehp()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
	int attack = GetDlgItemInt(IDC_attack),defense = GetDlgItemInt(IDC_defense),hp = GetDlgItemInt(IDC_hp),miss = GetDlgItemInt(IDC_miss);

	char str[100];
	sprintf_s(str,"Your hp is:%d",hp);
	short a = check(2);
	if(a == -1)return;
}


void CplayerDlg::OnEnChangemiss()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
	int attack = GetDlgItemInt(IDC_attack),defense = GetDlgItemInt(IDC_defense),hp = GetDlgItemInt(IDC_hp),miss = GetDlgItemInt(IDC_miss);

	char str[100];
	sprintf_s(str,"Your miss is:%d",miss);
	short a = check(3);
	if(a == -1)return;
}
