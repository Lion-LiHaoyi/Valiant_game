﻿// Valiantgame5.cpp: 定义控制台应用程序的入口点。
//

#include "stdafx.h"
#include "head.h"
#include "vis.h"

int main() {//游戏入口
	p[15][2][0] = 6, p[10][10][0] = 9, p[1][1][0] = 1, p[26][5][0] = 3, p[2][4][0] = 13, p[25][15][0] = 10, p[5][15][0] = 11;
	p[15][2][1] = p[10][10][1] = p[1][1][1] = p[26][5][1] = p[2][4][1] = p[25][15][1] = p[5][15][1] = 1;
	p[0][21][0] = 18, p[4][21][0] = 19;
	p[12][8][0] = 1, p[3][9][0] = 2, p[2][5][0] = 17, p[19][12][0] = 3;
	p[12][8][1] = p[3][9][1] = p[2][5][1] = p[19][12][1] = 2;
	p[8][7][0] = 1, p[5][14][0] = 2, p[25][12][0] = 3;
	p[8][7][1] = p[5][14][1] = p[25][12][1] = 3;
	p[12][7][0] = 1, p[4][17][0] = 2, p[25][11][0] = 3;
	p[12][7][1] = p[4][17][1] = p[25][11][1] = 4;
	p[1][3][0] = 1, p[13][5][0] = 2, p[3][10][0] = 3, p[27][15][0] = 4;
	p[1][3][1] = p[13][5][1] = p[3][10][1] = p[27][15][1] = 5;
	p[0][1][0] = 1, p[21][5][0] = 2, p[12][9][0] = 3, p[2][13][0] = 4, p[25][17][0] = 5;
	p[0][1][1] = p[21][5][1] = p[12][9][1] = p[2][13][1] = p[25][17][1] = 6;
	p[1][22][0] = 21, p[5][22][0] = 22, p[9][22][0] = 23, p[15][22][0] = 24, p[19][22][0] = 25, p[25][22][0] = 26, p[29][22][0] = 27;
	p[16][4][0] = 28, p[16][6][0] = 29, p[16][8][0] = 30, p[16][10][0] = 31;
	p[16][4][1] = p[16][6][1] = p[16][8][1] = p[16][10][1] = 1;
	p[0][25][0] = 32, p[0][26][0] = 33, p[0][27][0] = 34, p[0][28][0] = 35, p[0][29][0] = 36, p[0][30][0] = 37;
	p[0][31][0] = 38, p[0][32][0] = 39, p[0][33][0] = 40, p[0][34][0] = 41, p[0][35][0] = 42, p[0][36][0] = 43, p[0][37][0] = 44, p[0][38][0] = 45;
	p[0][25][1] = p[0][26][1] = p[0][27][1] = p[0][28][1] = p[0][29][1] = p[0][30][1] = p[0][31][1] = p[0][32][1] = p[0][33][1] = p[0][34][1] = p[0][35][1] = p[0][36][1] = p[0][37][1] = p[0][38][1] =  2;
	p[1][25][0] = 47, p[1][26][0] = 48;
	p[1][25][1] = p[1][26][1] = 3;
	p[4][0][0] = 49, p[11][0][0] = 50, p[18][0][0] = 51, p[26][0][0] = 52, p[35][0][0] = 53, p[4][3][0] = 54, p[11][3][0] = 55, p[18][3][0] = 56, p[26][3][0] = 57, p[35][3][0] = 58;
	p[4][6][0] = 59, p[18][6][0] = 60, p[30][6][0] = 61, p[0][9][0] = 62, p[44][3][0] = 63;
	p[4][0][1] = p[11][0][1] = p[18][0][1] = p[26][0][1] = p[35][0][1] = p[4][3][1] = p[11][3][1] = p[18][3][1] = p[26][3][1] = p[35][3][1] = p[4][6][1] = p[18][6][1] = p[30][6][1] = p[0][9][1] = p[44][3][1] = 4;
	system("mode con cols=150 lines=150");
	gotoxy(60, 20);
	CONSOLE_CURSOR_INFO cursor_info = { 1, 0 };
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
	Sleep(500);
	system("cls");
	res = MessageBox(NULL, _T("准备好开始游戏了吗？"), _T("提示"), MB_YESNO);
	if (res == IDNO) {
		MessageBox(NULL, _T("太慢了吧！"), _T("提示"), MB_OK);
		exit(0);
	}
	ofstream fi("D:\\Ture");
	fi << '\0';
f:
	system(".\\资源\\Login.exe");
	ifstream fin("D:\\Ture");
	fin >> key;
	if (!key.size()) {
		MessageBox(NULL, L"请登录后游玩", L"提示", MB_OK);
		goto f;
	}
	key = password(key);
	sprintf(buf, "D:\\Valiant_game\\%s\\Game.data", key.c_str());
	sprintf(buf2, "C:\\TDDownload\\Valiant_game\\%s\\Game.data", key.c_str());
	ifstream fin1(buf);
	Setjindutiao(30);
	system("color F0");
	Music(L".\\资源\\Seve.mp3");
	if (!fin1) {
		SlowDisplay("这是一个令人蛋疼的学生世界！\n\n师大附小时代师大附中师大联盟的校花，被一群好人（才怪）绑架了！\n\n伟大的学生党啊~拿起你们的节操,不，铁锹，不，武器，营救校花！\n\n\n");
		printf("选择你的职业：\n\n\t1 坦克 肉到绝望\n\n\t2 战士 不屈特性\n\n\t3 刺客 输出爆表\n\n\t4 法师 无限恢复\n\n\t5 射手 极高闪避\n\n");
		do {
			switch (cin >> choose_number, choose_number) {
			case 1:
				player = tank;
				n++;
				break;
			case 2:
				player = army;
				nn++;
				break;
			case 3:
				player = ack;
				nnn++;
				break;
			case 4:
				player = mag;
				nnnn++;
				break;
			case 5:
				player = gun;
				nnnnn++;
				break;
			}
		} while (choose_number != 1 && choose_number != 2 && choose_number != 3 && choose_number != 4 && choose_number != 5);
		SlowDisplay("输入你的名字与校花的名字（输一个按一下回车）\n\n\n");
		cin >> player.name;
		//		cout<<player.name;
		cin >> xiaohua_name;
		//		cout<<xiaohua_name;
		SlowDisplay("输入你的性别：");
		cin >> sex;
		if (sex != "男"&&sex != "女")SlowDisplay("本游戏暂时不支持非人类游玩"), exit(0);
		if (sex == "男")player.health += 10, player.defense += 2;
		else player.miss += 3, player.attack += 2;
		Setjindutiao(20);
	}
	else Open();
	OrdinaryAct();
	return 0;
}
string password(string a) {
	int len = a.size();
	for (int i = 0;i < len;i++) {
		a[i] = ~a[i];
	}
	return a;
}
void Color(int a) {//颜色
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), a);
	return;
}
int GetPoint() {//按键
f1:
	POINT pt;
	HWND h;
	int x = 0, y = 0, q = 0, X = 0, Y = 0, b = me ? 0 : battle;
	while (1) {
		h = GetForegroundWindow();
		GetCursorPos(&pt);
		ScreenToClient(h, &pt);
		x = pt.x / 16, y = pt.y / 16;
		if (q && (X != x * 2 || Y != y)) {
			gotoxy(X, Y);
			X = 2 * x, Y = y;
			cout << "□";
			q = 0;
		}
		if (p[x][y][0] && (X != x * 2 || Y != y)) {
			if (GetKeyState(VK_LBUTTON))q = 0;
			else q = 1;
			goto f4;
		f5:
			X = 2 * x, Y = y;
			Color(c2 * 16 + c1);
			gotoxy(X, Y),
				cout << "□";
			Color(c1 * 16 + c2);
		}
		if (GetKeyState(VK_LBUTTON)) {
			q = 0;
			break;
		}
	}
f4: if (!p[x][y][0])goto f1;
	if (p[x][y][0] < 17) {
		if (p[x][y][1] == ming)if (q)goto f5;
		else return p[x][y][0];
		else goto f1;
	}
	else if (p[x][y][0] == 17) {
		if (ming)if (q)goto f5;
		else return p[x][y][0];
		else goto f1;
	}
	else if (p[x][y][0] == 18) {
		if (ming)if (q)goto f5;
		else return p[x][y][0];
		else goto f1;
	}
	else if (p[x][y][0] == 19) {
		if (ming)if (q)goto f5;
		else menu();
		else goto f1;
	}
	else if (p[x][y][0] < 28) {
		if (b)if (q)goto f5;
		else return (p[x][y][0] - 20);
		else goto f1;
	}
	else if (p[x][y][0] < 64) {
		if (me == p[x][y][1]) {
			if (q)goto f5;
			else
				//			system("pause");
				me = 0;
			return (p[x][y][0] - 27);
		}
		else goto f1;
	}
	return 0;
}
int SuiJi() {//随机数
	srand((unsigned)time(NULL));
	return rand() % 10;
}
int SuiJi100() {//随机百分数
	srand((unsigned)time(NULL));
	return rand() % 100;
}
void zy() {//职业技
	gotoxy(0, 24);
	printf("熟练度：%d   职业技：%s\n\n\n   坦克按键 1\n\n\n   法师按键 2\n\n\n   射手按键 3\n\n\n  0,返回\n\n\n", fenshu, zyname.c_str());
	while (!cin >> choose_number) {
		SlowDisplay("输入错误,重新输入！\n\n\n");
		eatline();
		battlepre();
		printf("熟练度：%d   职业技：%s\n\n\n   坦克按键 1\n\n\n   法师按键 2\n\n\n   射手按键 3\n\n\n  0,返回\n\n\n", fenshu, zyname.c_str());
	}
	eatline();
	switch (choose_number) {
	case 3:
		if (kfzx >= 1 && huolianjishu >= 1) {
			SlowDisplay("飕飕飕！！！！\n\n\n");
			guai.health -= 300;
			huolianjishu--;
			if (player.miss < player.max_miss) {
				player.miss += 1;
			}
			else {
				player.miss = player.max_miss;
			}
			AttackResult();
		}
		else
			SlowDisplay("算了吧你\n\n\n");
		break;
	case 1:
		if (wrbsp >= 1 && huolianjishu >= 1) {
			if (jishu2 > 0) {
				SlowDisplay("集天地之力,发动至强一击！！！并提升自身属性！！！\n\n\n");
				jishu2--;
				huolianjishu--;
				guai.health -= 250;
				player.max_health += 20;
				player.defense += 2;
				AttackResult();
			}
			if (jishu2 <= 0) {
				huolianjishu--;
				SlowDisplay("集天地之力,发动至强一击！！！\n\n\n");
				guai.health -= 250;
				AttackResult();
			}
		}
		else
			printf("算了吧你\n\n\n");
		break;
	case 2:
		if (fnhl >= 1 && huolianjishu >= 1) {
			printf("造成%d伤害,汲取血,魔%d\n\n\n", player.level / 5 + player.max_mp / 2 + player.attack / 3, (player.level / 5 + player.max_mp / 2 + player.attack / 3) / 10);
			guai.health -= player.level / 5 + player.max_mp / 2 + player.attack / 3;
			huolianjishu--;
			if (player.health + (player.level / 5 + player.max_mp / 2 + player.attack / 3) / 10 < player.max_health) {
				player.health += (player.level / 5 + player.max_mp / 2 + player.attack / 3) / 10;
			}
			else {
				player.health = player.max_health;
			}
			if (player.mp + (player.level / 5 + player.max_mp / 2 + player.attack / 3) / 10 < player.max_mp) {
				player.mp += (player.level / 5 + player.max_mp / 2 + player.attack / 3) / 10;
			}
			else {
				player.mp = player.max_mp;
			}
			AttackResult();
		}
		else
			SlowDisplay("算了吧你\n\n\n");
		break;
	case 0:
		break;
	}
}
void jineng() {//技能
	gotoxy(0, 24);
	printf("技能：1，大爆菊术 2,饮血 3,太极生万物 0,返回\n\n\n");
	switch (cin >> choose_number, choose_number) {
	case 1:
		if (battle) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (dbjs > 0 && player.mp + diaozhui1nn / 4 >= 30) {
				SlowDisplay("赛扣及！！！\n\n\n");
				guai.health -= 150;
				player.mp -= 30;
				AttackResult();
			}
			else {
				printf("算了吧你\n\n\n");
			}
		}
		break;
	case 2:
		if (battle) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (yinxue > 0 && player.mp + diaozhui1nn / 4 >= 25) {
				printf("偷窃%d生命！！！\n\n\n", (player.health + diaozhui1nn + guai.health) / 20);
				guai.health -= 100;
				player.mp -= 25;
				if (player.health + (player.health + guai.health) / 20 >= player.max_health)
					player.health = player.max_health;
				else player.health += (player.health + guai.health) / 20;
				AttackResult();
			}
			else {
				printf("算了吧你\n\n\n");
			}
		}
		break;
	case 3:
		if (battle) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (tjsww > 0 && player.mp + diaozhui1nn >= 150) {
				SlowDisplay("万物复苏！！！！！满状态！！！并造成50点伤害！！！\n\n\n");
				player.health = player.max_health;
				player.mp -= 150;
				player.mp = player.max_mp;
				guai.health -= 50;
				tjsww--;
				AttackResult();
			}
			else {
				printf("算了吧你\n\n\n");
			}
		}
		break;
	case 0:
		break;
	default:
		printf("认真选技能！\n\n\n");
	}
}
void ChooseWupin() { //选择物品 并使用
	me = 2;
	gotoxy(0, 24);
	printf("物品：\n□止血草%d个\n□急救包%d个\n□云南白药%d个\n□超级云南白药%d个\n□手雷%d个\n□毒标%d个\n□手抛式原子弹%d个\n□B-boom%d个\n□逼能电磁炮\n□氧气袋%d个\n□电棍%d个\n□鱼雷%d个\n□秘药%d个\n□返回\n\n\n", cao, jijiubao, baiyao, superbaiyao, boom, dubiao, atom_boom, B, aircase, diangun, yulei, my);
	switch (GetPoint() - 4) {
	case 1:
		if (cao > 0) {
			SlowDisplay("使用止血草,HP增加80\n\n\n");
			cao--;
			if (player.health + 80 > player.max_health)player.health = player.max_health;
			else player.health += 80;
		}
		else MessageBox(NULL, _T("没有止血草了"), _T("注意"), MB_OK);
		break;
	case 2:
		if (jijiubao > 0) {
			SlowDisplay("使用急救包,HP增加100\n\n\n");
			jijiubao--;
			if (player.health + 100 > player.max_health)player.health = player.max_health;
			else player.health += 100;
		}
		else MessageBox(NULL, _T("没有急救包了"), _T("注意"), MB_OK);
		break;
	case 3:
		if (baiyao > 0) {
			SlowDisplay("使用云南白药,HP增加150\n\n\n");
			baiyao--;
			if (player.health + 150 > player.max_health)player.health = player.max_health;
			else player.health += 150;
		}
		else MessageBox(NULL, _T("没有云南白药了"), _T("注意"), MB_OK);
		break;
	case 4:
		if (superbaiyao > 0) {
			SlowDisplay("使用超级云南白药,HP增加200\n\n\n");
			superbaiyao--;
			if (player.health + 200 > player.max_health)player.health = player.max_health;
			else player.health += 200;
		}
		else MessageBox(NULL, _T("没有超级云南白药了"), _T("注意"), MB_OK);
		break;
	case 5:
		if (battle&&place_sign != place.sea) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (boom > 0) {
				SlowDisplay("使用手雷,敌人HP减少150\n\n\n");
				boom--;
				guai.health -= 150;
				AttackResult();
			}
			else MessageBox(NULL, _T("没有手雷了"), _T("注意"), MB_OK);
		}
		else MessageBox(NULL, _T("非战斗状态或在海中,不能使用手雷！"), _T("警告"), MB_OK);
		break;
	case 6:
		if (battle&&place_sign != place.sea) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (dubiao > 0) {
				SlowDisplay("使用毒标,敌人HP减少300\n\n\n");
				dubiao--;
				guai.health -= 300;
				AttackResult();
			}
			else MessageBox(NULL, _T("没有毒标了"), _T("注意"), MB_OK);
		}
		else MessageBox(NULL, _T("非战斗状态或在海中,不能使用毒标！"), _T("警告"), MB_OK);
		break;
	case 7:
		if (battle&&place_sign != place.sea) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (atom_boom > 0) {
				SlowDisplay("使用手抛式原子弹,敌人HP减少600\n\n\n");
				atom_boom--;
				guai.health -= 600;
				AttackResult();
			}
			else MessageBox(NULL, _T("没有手抛式原子弹了"), _T("注意"), MB_OK);
		}
		else MessageBox(NULL, _T("非战斗状态或在海中,不能使用手抛式原子弹！"), _T("警告"), MB_OK);
		break;
	case 8:
		if (battle) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (B > 0) {
				Boom();
				B--;
				AttackResult();
			}
			else MessageBox(NULL, _T("没有B-boom了"), _T("注意"), MB_OK);
		}
		else SlowDisplay("非战斗状态,不能使用B-boom!\n\n\n");
		break;
	case 9:
		if (battle) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (bi > 19&&zidan>0) {
				SlowDisplay("===================O",10);
				SlowDisplay("使用逼能电磁炮,敌人HP减少1500\n\n\n");
				bi -= 20;
				zidan --;
				guai.health -= 1500;
				AttackResult();
			}
			else MessageBox(NULL, _T("没有逼能或硬币了"), _T("注意"), MB_OK);
		}
		else MessageBox(NULL, _T("非战斗状态,不能使用逼能电磁炮！"), _T("警告"), MB_OK);
		break;
	case 10:
		if (aircase > 0) {
			SlowDisplay("使用氧气袋,氧气增加5\n\n\n");
			player.air--;
			if (player.air + 5 > player.max_air)player.air = player.max_air;
			else player.air += 5;
		}
		else MessageBox(NULL, _T("没有氧气袋了"), _T("注意"), MB_OK);
		break;
	case 11:
		if (battle&&place_sign != place.sea) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (diangun > 0) {
				if (bi > 4) {
					SlowDisplay("使用电棍,敌人HP减少200，并暂停3回合反击\n\n\n");
					diangun--;
					bi -= 5;
					guai.health -= 200;
					yun = 3;
					AttackResult();
				}
				else MessageBox(NULL, _T("电棍没有电了"), _T("注意"), MB_OK);
			}
			else MessageBox(NULL, _T("没有电棍了"), _T("注意"), MB_OK);
		}
		else MessageBox(NULL, _T("非战斗状态或在海中,不能使用电棍！"), _T("警告"), MB_OK);
		break;
	case 12:
		if (battle&&place_sign == place.sea) { //在战斗中(battle=1),否则(battle=0)不能使用攻击性物品
			if (yulei > 0) {
				SlowDisplay("使用鱼雷,敌人HP减少500\n\n\n");
				yulei--;
				guai.health -= 500;
				AttackResult();
			}
			else MessageBox(NULL, _T("没有鱼雷了"), _T("注意"), MB_OK);
		}
		else MessageBox(NULL, _T("非战斗状态或不在海中,不能使用鱼雷！"), _T("警告"), MB_OK);
		break;
	case 13:
		if (my > 0) {
			SlowDisplay("使用秘药,MP增加30\n\n\n");
			my--;
			if (player.mp + 30 > player.max_mp)player.mp = player.max_mp;
			else player.mp += 30;
		}
		else SlowDisplay("没有秘药了\n\n\n");
		break;
	case 14:
		break;
	}
	if (battle)BattleAct();
	system("cls");
	return;
}
int AttackResult() { //攻击结果：判断是否获胜 是否获得物品 和 是否升级
	if (guai.health <= 0) {
		battle = 0;
		printf("战斗胜利！获得金币%d,经验%d\n\n\n", guai.money, guai.exp);
		jishu3 = 1;
		huolianjishu = 4;
		player.exp += guai.exp;
		player.range_exp += guai.exp;
		fenshu++;
		bi++;
		if (SuiJi100() < 10)zidan++;
		money += guai.money;
		s = SuiJi();
		if (s < guai.wupinpro) {
			printf("%s爆出了%s\n\n\n", guai.name.c_str(), guai.wupin.c_str());
			AddWupin(guai.wupin_sign);
			if (lingpaia > 0 && lingpaib > 0) {
				SlowDisplay("一道金光闪出，令牌的两半竟合为一体了！！！\n\n");
				lingpaia--;
				lingpaib--;
				lingpai0++;
			}
			if (yumao == 4) {
				SlowDisplay("一道金光闪出，你拥有了一对羽翼！！！\n\n");
				yumao -= 4;
				yuyi++;;
			}
		}
		WhetherLevelUp();
		system("pause");
		if (guai.name == "舟凯学长") {
			Setjindutiao(20);
			SlowDisplay("舟凯的尸体倒下了，然而从迷雾的另一头走出了另一个神秘人：黄学长hzwer\n");
			battle = 1;
			guai = hzwer;
			printf("%s瞬移了过来，并扇了你一巴掌（你的HP减少了%d）\n\n", guai.name.c_str(), guai.attack + s - player.defense / 3);
			player.health -= guai.attack + s - player.defense / 3;
			BattleAct();
		}
		if (guai.name == "社会金鹰") {
			Setjindutiao(20);
			SlowDisplay("你思索了一下，随即哈哈大笑起来\n\n然后你惊恐的发现：你正在向下落！！！");
			place_sign = rand() % 16;
			player.health -= 100;
		}
		if (guai.name == "hzwer") {
			Boom();
			gotoxy(0, 10);
			SlowDisplay("杀怪数量：");
			printf("%d\t\t", fenshu);
			SlowDisplay("最终等级：");
			printf("%d\t\t", player.level);
			SlowDisplay("最终余额：");
			printf("%d\n\n\n", money);
			printf("战斗胜利，救出你的校花%s%s！！！\n\n\n", (sex == "男" ? "女友" : "闺蜜"), xiaohua_name.c_str());
			system("pause");
			exit(0);
		}
		Setjindutiao(20);
		OrdinaryAct();
		return 1; //攻击有结果了返回1,否则返回0,用于判断是否继续做战斗行为
	}
	else {
		s = SuiJi();
		if (SuiJi100() >= player.miss) {
			if (yun == 0) {
				if (doing) {
					gotoxy(5, 10);
					if (guai.attack + s - pet[0].defense / 3 < 0)pet[0].health -= 1, cout << "-1";
					else pet[0].health -= guai.attack + s - pet[0].defense / 3, printf("-%d", guai.attack + s - pet[0].defense / 3);
				}
				else {
					gotoxy(5, 4);
					if (SuiJi100() >= guai.double_attack) {
						if ((guai.attack + s - (player.defense + fang[0].defense) / 3) < 0) {
							player.health -= 1;
							printf("-1\n");
						}
						else {
							player.health -= guai.attack + s - (player.defense + fang[0].defense) / 3;
							printf("-%d\n", guai.attack + s - (player.defense + fang[0].defense) / 3);
						}
					}
					else {
						if ((2 * guai.attack + s - (player.defense + fang[0].defense) / 3) < 0) {
							player.health -= 2;
							printf("-2！！！\n");
						}
						else {
							player.health -= 2 * guai.attack + s - (player.defense + fang[0].defense) / 3;
							printf("-%d！！！\n", 2 * guai.attack + s - (player.defense + fang[0].defense) / 3);
						}
					}
				}
			}
			else {
				gotoxy(40, 5);
				printf("%s晕了，无法反击！\n\n", guai.name.c_str());
				yun--;
			}
		}
		else {
			gotoxy(5, 4);
			printf("%s", player.name.c_str());
			SlowDisplay("闪避！！！\n\n\n");
		}
		if (player.health + diaozhui1nn <= 0) {
			gotoxy(5, 5);
			if (dhwj >= 1 && jishu3 >= 1) {
				SlowDisplay("远古战神的英灵使你不屈不灭,获得");
				printf("%d", (player.max_health + diaozhui1nn) / 4);
				SlowDisplay("生命值！！！\n\n\n");
				player.health = 0;
				player.health += (player.max_health + diaozhui1nn) / 4;
				jishu3--;
			}
			else {
				battle = 0;
				printf("%s战死！金币掉落%d\n\n\n", player.name.c_str(), player.level * 50);
				Setjindutiao(20);
				jishu3 = 1;
				huolianjishu = 4;
				if (money < player.level * 50) {
					money = 0;
				}
				else {
					money -= player.level * 50;
				}
				player.health = player.max_health / 2;
				if (guai.name == "社会金鹰") {
					SlowDisplay("你正在向下落！！！");
					place_sign = rand() % 16;
					player.health -= 100;
				}
				Setjindutiao(20);
				OrdinaryAct();
				return 1;
			}
		}
		if (pet[0].health <= 0 && doing) {
			gotoxy(5, 10);
			printf("%s战死！！！", pet[0].name.c_str());
			doing = 0;
		}
	}
	return 0;
}
void AddWupin(int wupin_sign) {//物品增加
	switch (wupin_sign) {
	case 0:
		fang[1].num++;
		break;
	case 1:
		fang[4].num++;
		break;
	case 2:
		fang[3].num++;
		break;
	case 3:
		fang[2].num++;
		break;
	case 4:
		lingpaia++;
		break;
	case 5:
		gong[4].num++;
		break;
	case 6:
		gong[3].num++;
		break;
	case 7:
		gong[2].num++;
		break;
	case 8:
		gong[1].num++;
		break;
	case 9:
		lingpai1++;
		break;
	case 10:
		gong[5].num++;
		break;
	case 11:
		fang[5].num++;
		break;
	case 12:
		B++;
		break;
	case 13:
		juan1++;
		break;
	case 14:
		lingpai2++;
		break;
	case 15:
		lingpai3++;
		break;
	case 17:
		diaozhui1n++;
		break;
	case 18:
		diaozhui2n++;
		break;
	case 19:
		diaozhui3n++;
		break;
	case 20:
		honghua++;
		break;
	case 21:
		guhua++;
		break;
	case 22:
		sq++;
		break;
	case 23:
		jg++;
		break;
	case 24:
		wzmd++;
		break;
	case 25:
		sdxw++;
		break;
	case 26:
		lingpaib++;
		break;
	case 27:
		yumao++;
		break;
	case 28:
		pet[1].num++;
		break;
	}
}
void Pet() {
	me = 3;
	gotoxy(0, 24);
	printf("你要召唤谁？\n  □返回\n  □陈独秀の奖杯%d个", pet[1].num);
	//	GetPoint();
	//	cout<<1;
	choose_number = GetPoint() - 15 - 4;
	//	cout<<choose_number;
	if (choose_number != 1) {
		if (pet[choose_number - 1].num > 0) {
			pet[choose_number - 1].num--;
			pet[0] = pet[choose_number - 1];
			printf("%s在你的召唤下出现了！", pet[0].name.c_str());
			doing = 1;
		}
		else printf("信物不够，无法召唤%s", pet[choose_number - 1].name.c_str());
	}
}
void eatline() {//错误判断
	while (getchar() != '\n');
}
void battlepre() {//战斗界面
	Sleep(200);
	system("cls");
	gotoxy(5, 2);
	printf("%sHP：%d", player.name.c_str(), player.health);
	gotoxy(5, 3);
	printf("攻击力%d 防御力%d", player.attack + gong[0].attack, player.defense + fang[0].defense);
	gotoxy(40, 2);
	printf("%sHP：%d", guai.name.c_str(), guai.health);
	gotoxy(40, 3);
	cout << "攻击力" << guai.attack << " 防御力" << guai.defense;
	if (doing) {
		gotoxy(5, 8);
		printf("%s剩余HP：%d", pet[0].name.c_str(), pet[0].health);
		gotoxy(5, 9);
		printf("攻击力 %d 防御力 %d", pet[0].attack, pet[0].defense);
	}
	gotoxy(0, 18);
	puts("=============================================================================");
	printf("要怎么办?\n\n\n  □攻击  □物品  □查看状态  □技能  □职业专区  □逃跑  □召唤");
	gotoxy(0, 24);
}
void WhetherLevelUp() {//升级
	int l,n;
	if (player.level <= 15)l = player.range_exp / 100,n = 100;
	else if(player.level <= 25)l = player.range_exp / 300,n = 300;
	else if(player.level <= 45)l = player.range_exp / 600,n = 600;
	else if (player.level <= 85)l = player.range_exp / 900,n = 900;
	if (l == 0)return;
	if (l == 1) {
		printf("%s", player.name.c_str());
		SlowDisplay(" 升级！\n\n\n攻击力+3, 防御力+2, HP上限+20, MP上限+10,氧气上限+1\n\n\n");
		player.exp = player.exp + guai.exp - (player.exp + guai.exp) % 100;
		player.attack += 3;
		player.defense += 2;
		player.max_air++;
		player.max_health += 20;
		if (player.health + player.max_health / 2 < player.max_health)player.health += player.max_health / 2;
		else player.health = player.max_health;
		player.max_mp += 10;
		player.level++;
		player.range_exp = 0;
		player.exp = player.max_exp;
		player.max_exp += n;
	}
	else {
		printf("好厉害！连升%d级！", l);
		printf("攻击力+%d, 防御力+%d, HP上限+%d, MP上限+%d,氧气上限+%d\n\n\n", 3 * l, 2 * l, 20 * l, 10 * l, l);
		player.exp = player.exp + guai.exp - (player.exp + guai.exp) % 100;
		player.attack += 3 * l;
		player.max_air += l;
		player.defense += 2 * l;
		player.max_health += 20 * l;
		player.health = player.max_health;
		player.max_mp += 10 * l;
		player.level += l;
		player.max_air += l;
		player.range_exp = 0;
		player.exp = player.max_exp;
		player.max_exp += n * l;
	}	
}
void OrdinaryAct() { //判断位置
	NoMusic();
	Music(L".\\资源\\Seve.mp3");
	while (1) {
		switch (place_sign) {
		case 1:
		case 2:
		case 17:
		case 18:
			MapForpeople();
			break;
		case 3:
		case 4:
		case 5:
			MapForforest();
			break;
		case 6:
		case 7:
		case 8:
			MapForgrass();
			break;
		case 10:
		case 12:
		case 14:
		case 15:
		case 16:
			MapFordangerous();
			break;
		case 11:
			MapForsea();
			break;
		default:
			Map();
		}
	}
}
void DisplayState() {//显示状态
	gotoxy(0, 24);
	printf("%s 攻击力：%d+%d+%d=%d 防御力：%d+%d+%d=%d HP:%d/%d MP:%d/%d 闪避：%d 氧气：%d/%d\n\n\n", player.name.c_str(), player.attack, gong[0].attack, diaozhui2nn, player.attack + gong[0].attack + diaozhui2nn, player.defense, fang[0].defense, diaozhui3nn, player.defense + fang[0].defense + diaozhui3nn, player.health + diaozhui1nn, player.max_health + diaozhui1nn, player.mp + diaozhui1nn / 4, player.max_mp + diaozhui1nn / 4, player.miss, player.air, player.max_air);
	printf("武器：%s 防具： %s 饰品：%s  %s  %s   羽毛：%d  硬币：%d\n\n\n", gong[0].gongname.c_str(), fang[0].fangname.c_str(), diaozhui1name.c_str(), diaozhui2name.c_str(), diaozhui3name.c_str(), yumao, zidan);
	printf("等级：%d 经验：%d/%d 还需要%d经验升级 金币：%d  逼能：%d\n\n\n", player.level, player.exp, player.max_exp, player.max_exp - player.exp, money, bi);
	printf("魔法卷轴%d个 猩红精华%d 猩红卷轴%d个 远古精华%d个 远古卷轴%d个\n\n\n", juan1, honghua, juan2, guhua, juan3);
	printf("程序猿令牌%d个 草泥马令牌%d个 法克鱿令牌%d个 舟凯学长令牌%d个\n\n\n", lingpai0, lingpai1, lingpai2, lingpai3);
	system("pause");
	Setjindutiao(20);
}
void BattleAct() {//攻击模块
	if (player.name == guai.name) {
		printf("%s呵呵一声，便解决了%s", player.name.c_str(), guai.name.c_str());
		Sleep(500);
		Boom();
		AttackResult();
	}
	else if (xiaohua_name == guai.name&&sex == "男") {
		SlowDisplay("你很疑惑地看了看前方，那不是校花吗？\n\n直到对方对你发动攻击时，你才反应过来，然后愤怒地大骂起来：！@#%@……%*&");
		Sleep(500);
		battlepre();
		AttackResult();
	}
	NoMusic();
	Music(L".\\资源\\Monoday.mp3");
	while (1) {
		battlepre();
		if (doing) {
			gotoxy(5, 10);
			cout << "攻击！";
			gotoxy(40, 4);
			printf("-%d", pet[0].attack + SuiJi() - guai.defense / 3);
		}
		switch (GetPoint()) {
		case 1:
			s = SuiJi();
			if (s >= guai.miss || yun != 0) {
				if (dysls >= 1 && player.health <= player.max_health / 3) {
					gotoxy(0, 25);
					SlowDisplay("源于血脉的力量彻底觉醒！！！！攻击力增加1/4!！！\n\n\n");
					guai.health -= player.attack * 5 / 4 + s + gong[0].attack + diaozhui2nn - guai.defense / 3;
					player.health += (player.attack * 5 / 4 + s + gong[0].attack + diaozhui2nn - guai.defense / 3) / 3;
					gotoxy(40, 4);
					printf("-%d\n", player.attack * 5 / 4 + s + gong[0].attack + diaozhui2nn - guai.defense / 3);
					gotoxy(5, 4);
					printf("+%d\n", (player.attack * 5 / 4 + s + gong[0].attack + diaozhui2nn - guai.defense / 3) / 3);
					gotoxy(0, 26);
				}
				else {
					gotoxy(40, 4);
					printf("-%d\n", player.attack + s + gong[0].attack + diaozhui2nn - guai.defense / 3);
					guai.health -= player.attack + s + gong[0].attack + diaozhui2nn - guai.defense / 3;
					gotoxy(0, 26);
				}
			}
			else {
				gotoxy(40, 4);
				SlowDisplay("没打中！！！");
			}
			if (AttackResult())return; //如果攻击有结果(敌人或玩家战死)退出函数
			else continue;
		case 2:
			ChooseWupin();
			break; //选择物品,可以使用,战斗中允许使用攻击性物品
		case 3:
			DisplayState();
			break; //显示状态
		case 4:
			jineng();
			break;
		case 5:
			zy();
			break;
		case 6:
			s = SuiJi();
			if (s < 4) { //40%的概率可以逃跑
				gotoxy(5, 4);
				printf("%s逃跑了~\n\n\n", player.name.c_str());
				battle = 0;
				jishu3 = 1;
				huolianjishu = 4;
				Setjindutiao(20);
				return;
			}
			else if (s < 7) {
				gotoxy(5, 5);
				printf("%s逃跑失败！还遭到了%s的反攻！！！\n\n\n", player.name.c_str(), guai.name.c_str());
				if (AttackResult())return; //如果攻击有结果(敌人或玩家战死)退出函数
				else continue;
			}
			else {
				gotoxy(5, 4);
				printf("%s逃跑失败！\n\n\n", player.name.c_str());
			}
			break;
		case 7:
			Pet();
			break;
		}
	}
}
void SlowDisplay(char *p,int a) {//逐字输出
	while (1) {
		if (*p != 0)printf("%c", *p++);
		else break;
		Sleep(a);
	}
}
void gotoxy(int x, int y) {//显示跳转
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD c = { (short)x,(short)y };
	SetConsoleCursorPosition(hOut, c);
}
void menu() {//菜单栏
	ming = 0;
	me = 1;
	Setjindutiao(25);
	printf("\n\n\n\n\t\t\t\t□物品\n\n\t\t\t\t□装备\n\n\t\t\t\t□状态\n\n\t\t\t\t□返回\n\n\n");
	switch (GetPoint()) {
	case 1:
		me = 0;
		ChooseWupin();
		break;
	case 3:
		me = 0;
		DisplayState();
		break;
	case 2:
		me = 0;
		zhuangbei();
		break;
	case 0:
		me = 0;
		Setjindutiao(25);
		break;
	}
}
void Map() {//原始地图
	system("color F0");
	c1 = 15, c2 = 0;
	ColorEgg();
	ming = 1;
	gotoxy(30, 2);
	printf("□草原区域");
	gotoxy(20, 10);
	printf("□山脉区域");
	gotoxy(2, 1);
	printf("□人类最后的保留地");
	gotoxy(52, 5);
	printf("□森林区域");
	gotoxy(4, 4);
	printf("□法术幽谷");
	if (lingpai0) {
		gotoxy(50, 15);
		printf("□末路之地");
	}
	gotoxy(10, 15);
	printf("□边界海");
	gotoxy(0, 21);
	printf("□退出\t□菜单\n");
	switch (GetPoint()) {
	case 18:
		res = MessageBox(NULL, _T("确定退出游戏？"), _T("提示"), MB_YESNO);
		if (res == IDYES) {
			res = MessageBox(NULL, _T("是否创建新存档？（旧存档会被覆盖）"), _T("提示"), MB_YESNO);
			if (res == IDYES)Save();//向文件中更新数据;
			MessageBox(NULL, _T("退出"), _T("注意"), MB_OK);
			exit(0);
		}
		else MessageBox(NULL, _T("继续游戏！"), _T("提示"), MB_OK);
		break;
	case 19:
		menu();
		break;
	case 3:
		Setjindutiao(25);
		MapForforest();
		ColorEgg();
		break;
	case 10:
		if (lingpai0) {
			Setjindutiao(25);
			ColorEgg();
			MapFordangerous();
		}
		break;
	case 6:
		Setjindutiao(25);
		ColorEgg();
		MapForgrass();
		break;
	case 13:
		Setjindutiao(25);
		place_sign = place.fsyg;
		ming = 0;
		system("color D0");
		c1 = 0xd, c2 = 0;
		ColorEgg();
		s = SuiJi();
		if (s < 3) {
			battle = 1;
			guai = fashu;
			printf("%s瞅了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 6) {
			battle = 1;
			guai = hongshi;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			battle = 1;
			guai = gushi;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else {
			SlowDisplay("这里安全\n\n\n");
			Setjindutiao(25);
		}
		break;
	case 9:
		Setjindutiao(25);
		place_sign = place.mountain;
		ming = 0;
		system("color 70");
		c1 = 7, c2 = 0;
		ColorEgg();
		s = SuiJi();
		if (s < 7) {
			battle = 1;
			guai = asshole;
			printf("%s挪了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			battle = 1;
			guai = stone;
			printf("%s滚了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else {
			SlowDisplay("这里安全\n\n\n");
			Setjindutiao(25);
		}
		break;
	case 11:
		Setjindutiao(25);
		place_sign = place.sea;
		MapForsea();
		break;
	case 1:
		Setjindutiao(25);
		MapForpeople();
		break;
	}
}
void MapForforest() {//森林地图
	system("color 2F");
	c1 = 2, c2 = 0xf;
	ColorEgg();
	ming = 3;
	gotoxy(16, 7);
	printf("□森林一层");
	gotoxy(10, 14);
	printf("□森林二层");
	gotoxy(50, 12);
	printf("□森林三层");
	gotoxy(0, 21);
	printf("□返回\t□菜单\n\n\n");
	switch (GetPoint()) {
	case 18:
		place_sign = 0;
		Setjindutiao(20);
		break;
	case 1:
		place_sign = place.forest1;
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			Setjindutiao(25);
			battle = 1;
			guai = xiyi;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			Setjindutiao(25);
			battle = 1;
			guai = witch;
			printf("%s飘了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else {
			SlowDisplay("这里安全\n\n\n");
			Setjindutiao(25);
			//不用调用OAct函数,会自动执行OAct函数;
		}
		break;
	case 2:
		place_sign = place.forest2;
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			Setjindutiao(25);
			battle = 1;
			guai = witch;
			printf("%s飘了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			Setjindutiao(25);
			battle = 1;
			guai = strongman;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else {
			Setjindutiao(25);
			SlowDisplay("这里安全\n\n\n");
		}
		break;
	case 3:
		place_sign = place.forest3;
		s = SuiJi();
		ming = 0;
		if (s < 7) {
			Setjindutiao(25);
			battle = 1;
			guai = strongman;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			Setjindutiao(25);
			battle = 1;
			guai = big_strongman;
			SlowDisplay("一阵巨响在森林中回响：咚！！！咚！！！咚！！！随即森林巨人王扑了过来！！！\n\n\n");
			BattleAct();
			0;
		}
		else {
			SlowDisplay("这里安全\n\n\n");
			Setjindutiao(25);
		}
		break;
	}
}
void MapForgrass() {//草原地图
	system("color B0");
	c1 = 0xb, c2 = 0;
	ColorEgg();
	ming = 4;
	gotoxy(24, 7);
	printf("□草原一层");
	gotoxy(8, 17);
	printf("□草原二层");
	gotoxy(50, 11);
	printf("□草原三层");
	gotoxy(0, 21);
	printf("□返回\t□菜单\n\n\n");
	switch (GetPoint()) {
	case 18:
		place_sign = 0;
		Setjindutiao(20);
		break;
	case 3:
		Setjindutiao(25);
		place_sign = place.grass3;
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			battle = 1;
			guai = lion;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			battle = 1;
			guai = lions;
			SlowDisplay("一大波狮子飞快的冲了过来！！！\n\n\n");
			BattleAct();
		}
		else {
			SlowDisplay("这里安全\n\n\n");
		}
		break;
	case 2:
		place_sign = place.grass2;
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			Setjindutiao(25);
			battle = 1;
			guai = horse;
			printf("%s冲了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			Setjindutiao(25);
			battle = 1;
			guai = lion;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else {
			SlowDisplay("这里安全\n\n\n");
			Setjindutiao(25);
		}
		break;
	case 1:
		place_sign = place.grass1;
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			Setjindutiao(25);
			battle = 1;
			guai = bee;
			printf("%s飞了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			Setjindutiao(25);
			battle = 1;
			guai = horse;
			printf("%s冲了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else {
			SlowDisplay("这里安全\n\n\n");
			Setjindutiao(25);
		}
		break;
	}
}
void MapForpeople() {//居住区地图
	system("color 6F");
	c1 = 6, c2 = 0xf;
	ColorEgg();
	s = SuiJi();
	ming = 2;
	gotoxy(24, 8);
	printf("□酒吧");
	gotoxy(6, 9);
	printf("□旅店");
	gotoxy(4, 5);
	printf("□职业神殿");
	gotoxy(38, 12);
	printf("□竞技场");
	gotoxy(0, 21);
	printf("□返回\t□菜单\n\n\n");
	switch (GetPoint()) {
	case 18:
		place_sign = 0;
		Setjindutiao(20);
		break;
	case 17:
		if (sdxw > 0) {
			Setjindutiao(25);
			ColorEgg();
			ming = 0;
			place_sign = 17;
			printf("勇士,有什么事:1,领悟职业技能   2,购买职业顶级装备   0,返回\n\n\n");
			choose_number = 1;
			while (choose_number) {
				switch (cin >> choose_number, choose_number) {
				case 2:
					printf("坦克专属 1 霸壁锤岩\t\t2 万古不朽身\n\n\n战士专属 3 破空之刃\t\t4 圣灵光明体\n\n\n刺客专属 5 追魂幻刺\t\t6 狩猎者手凯\n\n\n法师专属 7 堕落天星杖\t\t8 幻光耀世衣\n\n\n射手专属 9 苍穹灭世波\t\t10 千里破风镜\n\n\n0,返回\t以上武器来源于游戏和小说\n\n\n");
					printf("PS:统一价:300000\n\n\n");
					choose_number = 1;
					while (choose_number) {
						switch (cin >> choose_number, choose_number) {
						case 0:
							Setjindutiao(20);
							SlowDisplay("走你！！！\n\n\n");
							Setjindutiao(25);
							break;
						}
					}
					break;
				case 1:
					printf("1 坦克专属 万仞崩山破(永久增肉)   \n\n\n2 战士专属 远古意志(被动不屈)   \n\n\n3 刺客专属 地狱之魂(被动饮血)\n\n\n4 法师专属 佛怒火莲(回魔回血)   \n\n\n5 射手专属 万箭破苍穹(闪避加成)   \n\n\n0 返回     以上技能来源于游戏或小说\n\n\n");
					choose_number = 1;
					while (choose_number) {
						switch (cin >> choose_number, choose_number) {
						case 1:
							if (n == 1 && jishu != 1) {
								SlowDisplay("领悟成功\n\n\n");
								wrbsp++;
								n++;
								jishu = 1;
								zyname = "万仞崩山破";
							}
							else
								SlowDisplay("滚！\n\n\n");
							break;
						case 2:
							if (nn == 1) {
								SlowDisplay("领悟成功\n\n\n");
								dhwj++;
								nn++;
								zyname = "远古意志";
							}
							else
								SlowDisplay("滚！\n\n\n");
							break;
						case 3:
							if (nnn == 1) {
								SlowDisplay("领悟成功\n\n\n");
								dysls++;
								nnn++;
								zyname = "地狱之魂";
							}
							else
								SlowDisplay("滚！\n\n\n");
							break;
						case 4:
							if (nnnn == 1) {
								SlowDisplay("领悟成功\n\n\n");
								fnhl++;
								nnnn++;
								zyname = "佛怒火莲";
							}
							else
								SlowDisplay("滚！\n\n\n");
							break;
						case 5:
							if (nnnnn == 1) {
								SlowDisplay("领悟成功\n\n\n");
								kfzx++;
								nnnnn++;
								zyname = "万箭破苍穹";
							}
							else
								SlowDisplay("滚！\n\n\n");
							break;
						case 0:
							Setjindutiao(20);
							SlowDisplay("走你！！！\n\n\n");
							Setjindutiao(25);
							break;
						}
					}
					break;
				case 0:
					Setjindutiao(20);
					SlowDisplay("走你！！！\n\n\n");
					Setjindutiao(25);
					break;
				}
			}
		}
		else {
			SlowDisplay("滚！！！");
			Setjindutiao(25);
		}
		break;
	case 2:
		Setjindutiao(25);
		ming = 0;
		place_sign = 2;
		ColorEgg();
		SlowDisplay("要住店吗? 800个金币 1,是 0,否\n\n\n");
		choose_number = 1;
		switch (cin >> choose_number, choose_number) {
		case 1:
			if (money - 800 < 0) { //判断钱是否够
				SlowDisplay("Sorry,你的钱不够~\n\n\n");
				Setjindutiao(25);
			}
			else {
				SlowDisplay("好好休息\n\tHP满,MP满,氧气满\n\t\t第二天了\n\n",100);
				money -= 800; //花费800住店费
				player.health = player.max_health;
				player.air = player.max_air;
				player.mp = player.max_mp;//体力满
				Setjindutiao(50);
			}
			break;
		case 0:
			SlowDisplay("下次再来！\n\n\n");
			Setjindutiao(25);
			break;
		default:
			printf("hotel talk error!\n\n\n");
			system("cls");
		}
		break;
	case 1:
		Setjindutiao(25);
		place_sign = place.bar;
		ming = 0;
		ColorEgg();
		printf("要和谁说话?\n\n\n1,红发女郎 2,赏金猎人 3,酒吧老板 4,大法师 5,回收店老板 0,返回\n\n\n");
		switch (cin >> choose_number, ColorEgg(), choose_number) {
		case 5:
			printf("至少有两个再来找我回收\n1 匕首 2 布衣 50金币  \n3 长剑 4 铁甲 100金币  \n5 碧血剑 6 银甲 300金币  \n7 绝世好剑 8 黄金圣衣 750金币\n\n另外这里有一些低价二手货，按9进入购买\n\n0 返回\n\n\n");
			switch (cin >> choose_number, choose_number) {
			case 1:
				if (gong[1].num >= 2) {
					SlowDisplay("金币加50.\n");
					gong[1].num--;
					money += 50;
				}
				else {
					SlowDisplay("匕首不够\n");
				}
				break;
			case 2:
				if (fang[1].num >= 2) {
					SlowDisplay("金币加50.\n");
					fang[1].num--;
					money += 50;
				}
				else {
					SlowDisplay("布衣不够\n");
				}
				break;
			case 3:
				if (gong[2].num >= 2) {
					SlowDisplay("金币加100.\n");
					gong[2].num--;
					money += 100;
				}
				else {
					SlowDisplay("长剑不够\n");
				}
				break;
			case 4:
				if (fang[2].num >= 2) {
					SlowDisplay("金币加100.\n");
					fang[2].num--;
					money += 100;
				}
				else {
					SlowDisplay("铁甲不够\n");
				}
				break;
			case 5:
				if (gong[3].num >= 2) {
					SlowDisplay("金币加300.\n");
					gong[3].num--;
					money += 300;
				}
				else {
					SlowDisplay("碧血剑不够\n");
				}
				break;
			case 6:
				if (fang[3].num >= 2) {
					SlowDisplay("金币加300.\n");
					fang[3].num--;
					money += 300;
				}
				else {
					SlowDisplay("银甲不够\n");
				}
				break;
			case 7:
				if (gong[4].num >= 2) {
					SlowDisplay("金币加750.\n");
					gong[4].num--;
					money += 750;
				}
				else {
					SlowDisplay("绝世好剑不够\n");
				}
				break;
			case 8:
				if (fang[1].num >= 2) {
					SlowDisplay("金币加750.\n");
					fang[1].num--;
					money += 750;
				}
				else {
					SlowDisplay("黄金圣衣不够\n");
				}
				break;
			case 9:
				printf("要买点什么?\n\n\n 1：止血草100金币 2：急救包180金币 3：云南白药200金币 4：手雷150金币 5：氧气袋100金币 6：电棍1500金币 7：鱼雷500金币 0,返回\n\n\n");
				choose_number = 1;
				while (choose_number) {
					switch (cin >> choose_number, choose_number) {
					case 1:
						if (money < 100) {
							SlowDisplay("钱不够！\n");
						}
						else {
							SlowDisplay("止血草+1\n");
							money = money - 100;
							cao++;
						}
						break;
					case 2:
						if (money < 180) {
							SlowDisplay("钱不够！\n");
						}
						else {
							SlowDisplay("急救包+1\n");
							money = money - 180;
							jijiubao++;
						}
						break;
					case 3:
						if (money < 200) {
							SlowDisplay("钱不够！\n");
						}
						else {
							SlowDisplay("云南白药+1\n");
							money = money - 200;
							baiyao++;
						}
						break;
					case 4:
						if (money < 150) {
							SlowDisplay("钱不够！\n");
						}
						else {
							SlowDisplay("手雷+1\n");
							money = money - 150;
							boom++;
						}
						break;
					case 5:
						if (money < 100) {
							SlowDisplay("钱不够！\n");
						}
						else {
							SlowDisplay("氧气袋+1\n");
							money = money - 100;
							aircase++;
						}
						break;
					case 6:
						if (money < 1500) {
							SlowDisplay("钱不够！\n");
						}
						else {
							SlowDisplay("电棍+1\n");
							money = money - 1500;
							diangun++;
						}
						break;
					case 7:
						if (money < 500) {
							SlowDisplay("钱不够！\n");
						}
						else {
							SlowDisplay("鱼雷+1\n");
							money = money - 500;
							yulei++;
						}
						break;
					case 0:
						break;
					default:
						SlowDisplay("输入错误\n\n\n");
					}
				}
			case 0:
				SlowDisplay("下次再来！！！");
				Setjindutiao(25);
				break;
			}
		case 0:
			Setjindutiao(20);
			break;
		case 1:
			SlowDisplay("红发女郎：\n\n\n 吧台边那个Hunter好帅啊！(~脸红~)\n\n\n听说他经常外出打猎,外面的路他应该很熟悉的！\n\n\n");
			Setjindutiao(25);
			break;
		case 2:
			if (player.level <= 30)
				SlowDisplay("赏金猎人：\n\n\n 年轻人！\n\n\n 你需要从山脉里的怪兽开始，\n\n\n 打败森林最深处的巨人王和草原最深处的狮群！\n\n\n 最后打败4位好人才可以救回校花！\n\n\n");
			Setjindutiao(25);
			if (player.level > 30)
				SlowDisplay("赏金猎人：\n\n\n FUCK ！！！！！！！！！！！！！！！！！，你这么强了，还找我干铞\n\n\n");
			Setjindutiao(25);
			break;
		case 3:
			printf("要喝点什么?\n\n\n 1,二锅头50金币 HP+20 2,XO酒100金币 HP+50 3,人头马面250金币 HP+100 4,富氧水,氧气+10,500金币,0,离开\n\n\n");
			choose_number = 1;
			while (choose_number) {
				switch (cin >> choose_number, choose_number) {
				case 4:
					if (money < 500) {
						SlowDisplay("钱不够！\n\n\n");
					}
					else {
						if (player.air + 10 <= player.max_air) {
							SlowDisplay("air+20.\n\n\n");
							money -= 500;
							player.air += 10;
						}
						else {
							SlowDisplay("air满了\n\n\n");
							player.air = player.max_air;
						}
					}
					break;
				case 1:
					if (money < 50) {
						SlowDisplay("钱不够！\n\n\n");
					}
					else {
						if (player.health + 20 <= player.max_health) {
							SlowDisplay("HP+20.\n\n\n");
							money -= 50;
							player.health += 20;
						}
						else {
							SlowDisplay("HP满了\n\n\n");
							player.health = player.max_health;
						}
					}
					break;
				case 2:
					if (money < 100) {
						SlowDisplay("钱不够！\n\n\n");
					}
					else {
						if (player.health + 80 <= player.max_health) {
							SlowDisplay("HP+80.\n\n\n");
							money -= 100;
							player.health += 80;
						}
						else {
							SlowDisplay("HP满了\n\n\n");
							player.health = player.max_health;
						}
					}
					break;
				case 3:
					if (money < 250) {
						SlowDisplay("钱不够！\n\n\n");
					}
					else {
						if (player.health + 150 <= player.max_health) {
							SlowDisplay("HP+150.\n\n\n");
							money -= 250;
							player.health += 150;
						}
						else {
							SlowDisplay("HP满了\n\n\n");
							player.health = player.max_health;
						}
					}
					break;
				case 0:
					SlowDisplay("下次再来！\n");
					break;
				}
			}
			break;
		case 4:
			printf("这些是我最新研制的心法：\n\n   1，秘药 10金币，回魔30\n\n   2,魔法卷轴 500金币\n\n   3,猩红卷轴 魔法卷轴+猩红精华\n\n   4,远古卷轴 魔法卷轴+远古精华\n\n   5大爆菊术 伤害150 耗魔30 等级要求15 魔法卷轴消耗10\n\n   6,饮血 伤害100 耗魔25 等级要求25 猩红卷轴消耗14 偷窃一定生命\n\n   7,太极生万物 伤害50 耗魔150 等级要求50 远古卷轴消耗20 状态全满 消耗性法术\n\n   0，离开\n\n\n");
			choose_number = 1;
			while (choose_number) {
				switch (cin >> choose_number, choose_number) {
				case 1:
					if (money < 10) {
						SlowDisplay("钱不够！\n\n\n");
					}
					else {
						if (player.mp + diaozhui1nn / 4 + 30 <= diaozhui1nn / 4 + player.max_mp) {
							SlowDisplay("MP+20.\n\n\n");
							money -= 10;
							player.mp += 30;
						}
						else {
							SlowDisplay("MP满了\n\n\n");
							player.mp = player.max_mp;
						}
					}
					break;
				case 2: {
					if (money < 500) {
						SlowDisplay("钱不够！\n\n\n");
					}
					else {
						printf("这是你的了\n\n\n");
						money -= 500;
						juan1++;
					}
				}
						break;
				case 3:
					if (juan1 < 1 || honghua < 1) {
						SlowDisplay("材料不够！\n\n\n");
					}
					else if (juan1 >= 1 && honghua >= 1) {
						printf("合成了猩红卷轴！\n\n\n");
						juan1--;
						honghua--;
						juan2++;
					}
					break;
				case 4:
					if (juan1 < 1 || guhua < 1) {
						SlowDisplay("材料不够！\n\n\n");
					}
					else if (juan1 >= 1 && guhua >= 1) {
						printf("合成了远古卷轴！\n\n\n");
						juan1--;
						guhua--;
						juan3++;
					}
					break;
					{
				case 5:
					if (player.level < 15 || juan1 < 10) {
						SlowDisplay("你的力量还不够！\n\n\n");
					}
					else {
						if (player.level >= 15 && juan1 >= 10) {
							SlowDisplay("爆菊心法尽收脑海\n\n\n");
							juan1 -= 10;
							dbjs++;
						}
					}
					break;
				case 6:
					if (player.level < 25 || juan2 < 14) {
						SlowDisplay("你的心理承受能力还不够！\n\n\n");
					}
					else {
						if (player.level >= 25 && juan2 >= 14) {
							SlowDisplay("恐怖的声音在心中回响\n\n\n");
							juan2 -= 14;
							yinxue++;
						}
					}
					break;
				case 7:
					if (player.level < 50 || juan3 < 20) {
						SlowDisplay("你的力量还不够！\n\n\n");
					}
					else {
						if (player.level >= 50 && juan3 >= 20) {
							SlowDisplay("伏羲的幻影悄悄浮现\n\n\n");
							juan3 -= 20;
							tjsww++;
						}
					}
					break;
				case 0:
					SlowDisplay("去吧，加油！！！\n\n\n");
					break;
					}
				}
			}
		}
		break;
	case 3:
		ColorEgg();
		place_sign = place.bar;
		ming = 0;
		Setjindutiao(25);
		puts("正在为您匹配对手");
		guai.name = "不明对手";
		guai.wupin = "不明物体";
	f2:
		guai.attack = player.attack + SuiJi100() - 50;
		printf("对手的攻击力是：%d\n", guai.attack);
		Sleep(1000);
		guai.defense = player.defense + SuiJi100() - 50;
		printf("对手的防御力是：%d\n", guai.defense);
		Sleep(1000);
		guai.health = player.max_health + SuiJi100() - 50;
		guai.max_health = guai.health;
		printf("对手的HP是：%d\n", guai.health);
		guai.money = guai.health / 3;
		guai.exp = guai.health / 6;
		guai.wupin_sign = rand() % 29;
		guai.miss = 0;
		guai.double_attack = 0;
		if (guai.attack <= 0 || guai.defense <= 0 || guai.health <= 0) {
			puts("出现错误，将重新为您匹配");
			system("cls");
			goto f2;
		}
		battle = 1;
		BattleAct();
	}
}
void MapForsea() {//海洋地图
	system("color 3F");
	c1 = 3, c2 = 0xf;
	ming = 5;
	gotoxy(26, 5);
	printf("□日光区(1氧)");
	gotoxy(6, 10);
	printf("□暮光区(2氧)");
	gotoxy(54, 15);
	printf("□午夜区(3氧)");
	gotoxy(2, 3);
	printf("□海滩");
	gotoxy(0, 21);
	printf("□返回\t□菜单\n\n\n");
	switch (GetPoint()) {
	case 18:
		place_sign = 0;
		Setjindutiao(20);
		break;
	case 1:
		battle = 1;
		ming = 0;
		guai = wugui;
		Setjindutiao(25);
		SlowDisplay("巨......龟......以......一......种......慢......到......令......人......绝......望......的......速......度......爬......了......过......来......\n\n\n");
		BattleAct();
		break;
	case 2:
		ming = 0;
		if (player.air >= 1) {
			player.air--;
			s = SuiJi();
			if (s < 7) {
				battle = 1;
				guai = shark;
				Setjindutiao(25);
				printf("%s冲了过来！\n\n\n", guai.name.c_str());
				BattleAct();
			}
			else if (s < 9) {
				battle = 1;
				guai = bigshark;
				Setjindutiao(25);
				printf("%s冲了过来！\n\n\n", guai.name.c_str());
				BattleAct();
			}
			else {
				Setjindutiao(25);
				SlowDisplay("这里安全\n\n\n");
			}
		}
		else {
			battle = 0;
			player.air = player.max_air / 2;
			player.health = player.max_health / 5;
			money -= 500;
			SlowDisplay("你眼前一黑,然后就什么也不知道了");
			Setjindutiao(25);
		}
		break;
	case 3:
		ming = 0;
		if (player.air >= 2) {
			player.air -= 2;
			battle = 1;
			guai = lj;
			Setjindutiao(25);
			SlowDisplay("蓝鲸游了过来！！！\n\n\n");
			BattleAct();
		}
		else {
			battle = 0;
			player.air = player.max_air / 2;
			player.health = player.max_health / 5;
			money -= 500;
			Setjindutiao(25);
			SlowDisplay("你眼前一黑,然后就什么也不知道了");
			Setjindutiao(25);
		}
		break;
	case 4:
		ming = 0;
		Setjindutiao(25);
		system("color 07");
		if (player.air >= 3) {
			player.air -= 3;
			s = SuiJi();
			if (s < 6) {
				battle = 1;
				guai = wuzei;
				printf("%s游了过来！\n\n\n", guai.name.c_str());
				BattleAct();
			}
			else if (s < 8) {
				battle = 1;
				guai = sly;
				SlowDisplay("你发现了一条圣灵鱼！！！！！\n\n\n");
				BattleAct();
			}
			else {
				if (wzmd < 1 || sq < 1 || jg < 1) {
					battle = 0;
					SlowDisplay("你总觉得这里有些奇怪,但说不出名堂");
					Setjindutiao(25);
				}
				else {
					battle = 0;
					SlowDisplay("你的鲸骨,鲨鳍还有乌贼墨胆突然被一股神秘力量吸走,你出于好奇跟了上去\n\n");
					SlowDisplay("它们停在了一处古迹前,你抬头一看：Atlantis\n");
					res = MessageBox(NULL, _T("想进去吗？"), _T("提示"), MB_YESNO);
					if (res = IDYES)
						if (a) {
							wzmd--;
							sq--;
							jg--;
							SlowDisplay("你身上的羽翼突然飘了起来，带着你飞上了一个地方");
							Setjindutiao(25);
							system("color F0");
							SlowDisplay("你面前是Bjarne Stroustrup博士（C++创始人，此处纯属虚构），他说：\n\n\t“hzwer那个家伙才是夺走校花的真正凶手，我会送你一把大保健，帮你传送到那去，接下来就靠你了”");
							place_sign = 0;
							gong[0].attack = 1000;
							gong[0].gongname = "C++大保健";
							guai = zk;
							battle = 1;
							system("color 0F");
							BattleAct();
						}
						else {
							battle = 0;
							player.air = player.max_air / 2;
							player.health = player.max_health / 5;
							money -= 500;
							SlowDisplay("你眼前一黑,然后就什么也不知道了");
							Setjindutiao(25);
						}
						Setjindutiao(25);
				}
			}
		}
		else {
			battle = 0;
			player.air = player.max_air / 2;
			player.health = player.max_health / 5;
			money -= 500;
			SlowDisplay("你眼前一黑,然后就什么也不知道了");
			Setjindutiao(25);
		}
		break;
	}
}
void MapFordangerous() {//危险区地图
	system("color FC");
	c1 = 0xf, c2 = 0xc;
	ColorEgg();
	ming = 6;
	gotoxy(4, 13);
	printf("□法克鱿大海");
	gotoxy(24, 9);
	printf("□草泥马平原");
	gotoxy(0, 1);
	printf("□马勒戈壁");
	gotoxy(42, 5);
	printf("□机械之城");
	gotoxy(50, 17);
	printf("□神秘实验室");
	gotoxy(0, 21);
	printf("□返回\t□菜单\n\n\n");
	switch (GetPoint()) {
	case 5:
		Setjindutiao(25);
		place_sign = place.jd;
		system("color 0F");
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			SlowDisplay("前方迷雾重重\n\n\n");
			Setjindutiao(25);
		}
		else {
			battle = 1;
			if (lingpai3) {
				SlowDisplay("舟凯学长：\n\n\n 打败我就可以救出校花，来吧\n\n\n");
				guai = zk;
				printf("%s扑了过来！\n\n\n", guai.name.c_str());
				SlowDisplay("一股神秘力量限制了B??boom的使用\n\n\n");
				B = 0;
				BattleAct();
			}
			else SlowDisplay("舟凯学长：\n\n\n 年轻人,你好啊.如果你有我的令牌,我可以告诉你校花的下落哦~\n\n\n");
			Setjindutiao(25);
		}
		break;
	case 4:
		Setjindutiao(25);
		place_sign = place.fky;
		system("color 9F");
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			battle = 1;
			guai = ffk;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			battle = 1;
			if (lingpai2) {
				SlowDisplay("法克逸：\n\n\n 想救校花？来打架呀！！\n\n\n");
				guai = fky;
				printf("%s扑了过来！\n\n\n", guai.name.c_str());
				BattleAct();
			}
			else SlowDisplay("法克逸：\n\n\n 年轻人,你好啊.如果你有法克鱿令牌,我可以告诉你校花的下落哦~\n\n\n");
			Setjindutiao(25);
		}
		else SlowDisplay("这里安全\n\n\n");
		break;
	case 2:
		Setjindutiao(25);
		place_sign = place.mesh;
		ming = 0;
		system("color 0C");
		s = SuiJi();
		if (s < 7) {
			battle = 1;
			guai = Bman;
			printf("%s发现你了！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			battle = 0;
			printf("齿轮轧到了%s！！！\n\n\n", player.name.c_str());
			player.health = player.health - 15;
			Setjindutiao(25);
		}
		else {
			SlowDisplay("这里安全\n\n\n");
			Setjindutiao(25);
		}
		break;
	case 1:
		Setjindutiao(25);
		place_sign = place.mlgb;
		system("color E0");
		ming = 0;
		s = SuiJi();
		if (s < 7) {
			battle = 1;
			guai = cxy;
			printf("%s跳了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			battle = 1;
			if (lingpai0) {
				SlowDisplay("程序廖：\n\n\n 哈哈,年轻人,做的不错,不过...嘿嘿,你上当啦！程序猿令牌我要了,校花你也别想带走！\n\n\n");
				guai = shitu;
				printf("%s扑了过来！\n\n\n", guai.name.c_str());
				BattleAct();
			}
			else SlowDisplay("程序廖：\n\n\n 年轻人,你好啊.如果你有程序猿令牌,我可以告诉你校花的下落哦~\n\n\n");
			Setjindutiao(25);
		}
		else SlowDisplay("这里安全\n\n\n");
		break;
	case 3:
		place_sign = place.cnm;
		Setjindutiao(25);
		ming = 0;
		system("color B0");
		s = SuiJi();
		if (s < 7) {
			battle = 1;
			guai = ccm;
			printf("%s扑了过来！\n\n\n", guai.name.c_str());
			BattleAct();
		}
		else if (s < 9) {
			battle = 1;
			if (lingpai1) {
				SlowDisplay("草泥?:\n\n\n 哈哈,想救校花，先打败我！！\n\n\n");
				guai = cnx;
				printf("%s扑了过来！\n\n\n", guai.name.c_str());
				BattleAct();
			}
			else SlowDisplay("草泥?:\n\n\n 年轻人,你好啊.如果你有草泥马令牌,我可以告诉你校花的下落哦~\n\n\n");
			Setjindutiao(25);
		}
		else SlowDisplay("这里安全\n\n\n");
		break;
	case 18:
		place_sign = 0;
		Setjindutiao(20);
		break;
	}
}
void zhuangbei() {//装备
	Setjindutiao(25);
	me = 4;
	printf("攻装：  □匕首：%2d个  □长剑：%2d个  □碧血剑：%2d个  □绝世好剑：%2d个  □狂鲨利齿：%2d个\n\n\n", gong[1].num, gong[2].num, gong[3].num, gong[4].num, gong[5].num);
	printf("防装：  □布衣：%2d个  □铁甲：%2d个  □银甲：%2d个    □黄金圣衣：%2d个  □神龟之盾：%2d个\t□返回\n\n\n", fang[1].num, fang[2].num, fang[3].num, fang[4].num, fang[5].num);
	printf("饰品：  □程序猿吊坠%2d(生命,法术)   □草泥马吊坠%2d（攻击）  □法克鱿吊坠%2d（防御）\n\n\n", diaozhui1n, diaozhui2n, diaozhui3n);
	printf("□羽翼\n\n\n");
	SlowDisplay("选择要装备的武器或防具：\n\n\n");
	choose_number = GetPoint() - 15 - 2 - 4;
	if (choose_number > 0 && choose_number < 6) {
		if (gong[choose_number].num > 0) {
			gong[0].gongname = gong[choose_number].gongname;
			gong[0].attack = gong[choose_number].attack;
			printf("拿起了%s", gong[choose_number].gongname.c_str());
		}
		else printf("你没有%s可以装备", gong[choose_number].gongname.c_str());
		Setjindutiao(25);
	}
	else if (choose_number > 5 && choose_number <= 10) {
		choose_number -= 5;
		if (fang[choose_number].num > 0) {
			fang[0].fangname = fang[choose_number].fangname;
			fang[0].defense = fang[choose_number].defense;
			printf("拿起了%s", fang[0].fangname.c_str());
		}
		else printf("你没有%s可以装备", fang[choose_number].fangname.c_str());
		Setjindutiao(25);
	}
	else switch (choose_number) {
	case 11:
		if (diaozhui1n >= 1) {
			SlowDisplay("戴上了程序猿吊坠\n\n\n");
			diaozhui1nn = diaozhui1;
			diaozhui1name = "程序猿吊坠";
			Setjindutiao(25);
		}
		else SlowDisplay("你没有程序猿吊坠可以装备\n\n\n");
		Setjindutiao(25);
		break;
	case 12:
		if (diaozhui2n >= 1) {
			SlowDisplay("戴上了草泥马吊坠\n\n\n");
			diaozhui2nn = diaozhui2;
			diaozhui2name = "草泥马吊坠";
			Setjindutiao(25);
		}
		else SlowDisplay("你没有草泥马吊坠可以装备\n\n\n");
		Setjindutiao(25);
		break;
	case 13:
		if (diaozhui3n >= 1) {
			SlowDisplay("戴上了法克鱿吊坠\n\n\n");
			diaozhui3nn = diaozhui3;
			diaozhui3name = "法克鱿吊坠";
			Setjindutiao(25);
		}
		else SlowDisplay("你没有法克鱿吊坠可以装备\n\n\n");
		Setjindutiao(25);
		break;
	case 14:
		if (yuyi >= 1) {
			SlowDisplay("穿上了羽翼\n\n\n");
			a = 1;
			player.miss++;
			Setjindutiao(25);
		}
		else SlowDisplay("你没有羽翼可以装备\n\n\n");
		Setjindutiao(25);
		break;
	case 15:
		SlowDisplay("未更换装备\n\n\n");
		Setjindutiao(25);
		break;
	}
}
void Boom() {//Boom
	Setjindutiao(20);
	gotoxy(74, 17);
	puts("o");
	Sleep(200);
	system("cls");
	gotoxy(74, 15);
	puts("+");
	gotoxy(70, 17);
	puts("+       +");
	gotoxy(74, 19);
	puts("+");
	Sleep(200);
	system("cls");
	gotoxy(74, 13);
	puts("+");
	gotoxy(68, 15);
	puts("+           +");
	gotoxy(66, 17);
	puts("+               +");
	gotoxy(68, 19);
	puts("+           +");
	gotoxy(74, 21);
	puts("+");
	Sleep(200);
	system("cls");
	gotoxy(74, 11);
	puts("+");
	gotoxy(66, 13);
	puts("+               +");
	gotoxy(62, 17);
	puts("+                       +");
	gotoxy(66, 21);
	puts("+               +");
	gotoxy(74, 23);
	puts("+");
	Sleep(200);
	system("cls");
	gotoxy(74, 2);
	puts("+");
	gotoxy(64, 3);
	puts("+                    +");
	gotoxy(56, 5);
	puts("+                                   +");
	gotoxy(50, 8);
	puts("+                                               +");
	gotoxy(46, 12);
	puts("+                                                       +");
	gotoxy(44, 17);
	puts("+                                                           +");
	gotoxy(46, 22);
	puts("+                                                       +");
	gotoxy(50, 25);
	puts("+                                               +");
	gotoxy(56, 28);
	puts("+                                   +");
	gotoxy(64, 30);
	puts("+                    +");
	gotoxy(74, 31);
	puts("+");
	Sleep(200);
	system("cls");
	gotoxy(0, 13);
	puts("\t\t\t\t\t■■■■■    ■■■■■    ■■■■■    ■■      ■■  ■");
	puts("\t\t\t\t\t■      ■    ■      ■    ■      ■    ■ ■    ■ ■  ■");
	puts("\t\t\t\t\t■      ■    ■      ■    ■      ■    ■  ■  ■  ■  ■");
	puts("\t\t\t\t\t■■■■      ■      ■    ■      ■    ■   ■■   ■  ■");
	puts("\t\t\t\t\t■      ■    ■      ■    ■      ■    ■    ■    ■  ■");
	puts("\t\t\t\t\t■      ■    ■      ■    ■      ■    ■    ■    ■    ");
	puts("\t\t\t\t\t■■■■■    ■■■■■    ■■■■■    ■    ■    ■  ■");
	guai.health -= 6666;
	Setjindutiao(20);
}
void Setjindutiao(int p) {//进度条
	Sleep(500);
	system("cls");
	GetLocalTime(&Time);
	int x = Time.wHour, f = Time.wMinute, y = Time.wMonth, r = Time.wDay, n = Time.wYear, m = Time.wSecond;
	gotoxy(0, 0);
	SetConsoleTitle(_T("勇者游戏4.3.6")); //标题
	puts("勇者游戏工作室");
	puts("╔════════════════════════════════════════════════════════════╗");
	puts("║                                                            ║");
	puts("╚════════════════════════════════════════════════════════════╝");
	printf("\t正在加载......... %d年%d月%d日  %02d:%02d:%02d\t\t", n, y, r, x, f, m);
	printf("\t勇者游戏\t");
	if (battle)printf("战斗！！！");
	cout << endl << say[rand() % 6];
	gotoxy(2, 2);
	for (int i = 0; i < 30; i++) {
		GetLocalTime(&Time);
		m = Time.wSecond;
		Sleep(p);
		printf("■");
		gotoxy(0, 4);
		printf("\t正在加载......... %d年%d月%d日  %02d:%02d:%02d\t\t", n, y, r, x, f, m);
		gotoxy(4 + 2 * i, 2);
	}
	system("cls");
}
void ColorEgg() {//彩蛋
	s = SuiJi100();
	if (s < 6) {
		battle = 1;
		guai = butterfly;
		SlowDisplay("一只雅蠛蝶飞了过来！！！\n\n\n");
		BattleAct();
	}
	else if (s < 9) {
		battle = 1;
		guai = jinying;
		SlowDisplay("一阵狂风刮来，社会金鹰扑了下来，把你叼上了天空！！！\n\n\n\t你悬浮在天上，社会金鹰用鹰语向你喊道：If I lose, I'll reverse my name!!!");
		BattleAct();
	}
	else if (s < 11) {
		SlowDisplay("突然下雨了\n\n\n");
		GetLocalTime(&Time);
		int y = Time.wMonth;
		if (y > 1 && y < 5) {
			SlowDisplay("像花针一样的春雨把你扎死了！！！\n\n\n");
			player.health = 0;
			printf("%s死亡！金币掉落%d\n\n\n", player.name.c_str(), player.level * 50);
			if (money < player.level * 50) {
				money = 0;
			}
			else {
				money -= player.level * 50;
			}
			Setjindutiao(20);
		}
		else if (y > 8 && y < 12) {
			SlowDisplay("旁边树上的橘子结果了，你摘了一颗下来吃。恢复了10点血（滑稽）。你看了看远处，远方似乎正在建造一个火车站。（滑稽）\n\n\n");
			player.health += 10;
		}
		else {
			SlowDisplay("你得了感冒！！！\n\n\n");
			player.health -= 20;
			SlowDisplay("\t为了治好感冒，你被医生坑了50金币（约合人民币250元）......");
			money -= 50;
			Setjindutiao(20);
		}
	}
	else if (s < 14) {
		battle = 1;
		guai = dog;
		SlowDisplay("愤怒的单身狗冲了过来！\n\n\n");
		BattleAct();
	}
	else if (s < 16) {
		battle = 1;
		guai = duxiu;
		SlowDisplay("你前方出现了一道橘黄色的光束，随即陈独秀冲了过来！！！");
		BattleAct();
	}
}
void Save() {//保存
	ofstream fout(buf);
	fout << player.name << ' ' << player.attack << ' ' << player.defense << ' ' << player.health << ' ' << player.mp << ' ' << player.max_health << ' ' << player.max_mp << ' ' << player.level << ' ' << player.exp << ' ' << player.range_exp << ' ' << player.max_exp << ' ' << player.air << ' ' << player.max_air << ' ' << player.miss << ' ' << player.max_miss << ' ' << money << ' '
		<< bi << ' ' << jishu << ' ' << jishu2 << ' ' << jishu3 << ' ' << huolianjishu << ' ' << wzmd << ' ' << jg << ' ' << sdxw << ' ' << sq << ' ' << bbcy << ' ' << pkzr << ' ' << zhhc << ' ' << dltxz << ' ' << cqmsb << ' ' << wgbxs << ' ' << slgmt << ' ' << slzsk << ' ' << hgysy << ' ' << qlpfj << ' ' << cao << ' ' << jijiubao << ' ' << baiyao << ' ' << superbaiyao << ' '
		<< boom << ' ' << dubiao << ' ' << atom_boom << ' ' << B << ' ' << juan1 << ' ' << my << ' ' << aircase << ' ' << diangun << ' ' << yulei << ' ' << zidan << ' ' << dbjs << ' ' << yinxue << ' ' << tjsww << ' ' << lingpaia << ' ' << lingpaib << ' ' << lingpai0 << ' ' << lingpai1 << ' ' << lingpai2 << ' ' << lingpai3 << ' ' << yumao << ' ' << honghua << ' ' << guhua << ' '
		<< juan2 << ' ' << juan3 << ' ' << fenshu << ' ' << n << ' ' << nn << ' ' << nnn << ' ' << nnnn << ' ' << nnnnn << ' ' << wrbsp << ' ' << dhwj << ' ' << dysls << ' ' << fnhl << ' ' << kfzx << ' ' << fang[0].defense << ' ' << fang[1].num << ' ' << fang[2].num << ' ' << fang[3].num << ' ' << fang[4].num << ' ' << fang[5].num << ' ' << yuyi << ' ' << a << ' ' << sex << ' ' << xiaohua_name << ' '
		<< gong[0].attack << ' ' << gong[1].num << ' ' << gong[2].num << ' ' << gong[3].num << ' ' << gong[4].num << ' ' << gong[5].num << ' ' << diaozhui1nn << ' ' << diaozhui2nn << ' ' << diaozhui3nn << ' ' << diaozhui1n << ' ' << diaozhui2n << ' ' << diaozhui3n << ' ' << gong[0].gongname << ' ' << fang[0].fangname << ' ' << diaozhui1name << ' ' << diaozhui2name << ' ' << diaozhui3name << ' ' << zyname << ' '
		<< pet[1].num;
	fout.close();
	ofstream fo(buf2);
	fo << player.name << ' ' << player.attack << ' ' << player.defense << ' ' << player.health << ' ' << player.mp << ' ' << player.max_health << ' ' << player.max_mp << ' ' << player.level << ' ' << player.exp << ' ' << player.range_exp << ' ' << player.max_exp << ' ' << player.air << ' ' << player.max_air << ' ' << player.miss << ' ' << player.max_miss << ' ' << money << ' '
		<< bi << ' ' << jishu << ' ' << jishu2 << ' ' << jishu3 << ' ' << huolianjishu << ' ' << wzmd << ' ' << jg << ' ' << sdxw << ' ' << sq << ' ' << bbcy << ' ' << pkzr << ' ' << zhhc << ' ' << dltxz << ' ' << cqmsb << ' ' << wgbxs << ' ' << slgmt << ' ' << slzsk << ' ' << hgysy << ' ' << qlpfj << ' ' << cao << ' ' << jijiubao << ' ' << baiyao << ' ' << superbaiyao << ' '
		<< boom << ' ' << dubiao << ' ' << atom_boom << ' ' << B << ' ' << juan1 << ' ' << my << ' ' << aircase << ' ' << diangun << ' ' << yulei << ' ' << zidan << ' ' << dbjs << ' ' << yinxue << ' ' << tjsww << ' ' << lingpaia << ' ' << lingpaib << ' ' << lingpai0 << ' ' << lingpai1 << ' ' << lingpai2 << ' ' << lingpai3 << ' ' << yumao << ' ' << honghua << ' ' << guhua << ' '
		<< juan2 << ' ' << juan3 << ' ' << fenshu << ' ' << n << ' ' << nn << ' ' << nnn << ' ' << nnnn << ' ' << nnnnn << ' ' << wrbsp << ' ' << dhwj << ' ' << dysls << ' ' << fnhl << ' ' << kfzx << ' ' << fang[0].defense << ' ' << fang[1].num << ' ' << fang[2].num << ' ' << fang[3].num << ' ' << fang[4].num << ' ' << fang[5].num << ' ' << yuyi << ' ' << a << ' ' << sex << ' ' << xiaohua_name << ' '
		<< gong[0].attack << ' ' << gong[1].num << ' ' << gong[2].num << ' ' << gong[3].num << ' ' << gong[4].num << ' ' << gong[5].num << ' ' << diaozhui1nn << ' ' << diaozhui2nn << ' ' << diaozhui3nn << ' ' << diaozhui1n << ' ' << diaozhui2n << ' ' << diaozhui3n << ' ' << gong[0].gongname << ' ' << fang[0].fangname << ' ' << diaozhui1name << ' ' << diaozhui2name << ' ' << diaozhui3name << ' ' << zyname << ' '
		<< pet[1].num;
	fo.close();
}
void Open() {//读取
	ifstream fin(buf);
	ifstream fi(buf2);
	if (!fin) {
		MessageBox(NULL, _T("你还没有存档！"), _T("注意"), MB_OK);
		main();
	}
	string s[2];
	getline(fin, s[0]);
	getline(fi, s[1]);
	if (s[0] != s[1]) {
		MessageBox(NULL, _T("此存档不正确"), _T("注意"), MB_OK);
		MessageBox(NULL, _T("正在为您销毁存档"), _T("注意"), MB_OK);
		ofstream fout(buf);
		ofstream fo(buf2);
		fout << ' ';
		fo << ' ';
		main();
	}
	ifstream fin0(buf);
	fin0 >> player.name >> player.attack >> player.defense >> player.health >> player.mp >> player.max_health >> player.max_mp >> player.level >> player.exp >> player.range_exp >> player.max_exp >> player.air >> player.max_air >> player.miss >> player.max_miss >> money >> bi >> jishu >> jishu2 >> jishu3 >> huolianjishu >> wzmd >> jg >> sdxw >> sq >> bbcy >> pkzr >> zhhc >> dltxz >> cqmsb
		>> wgbxs >> slgmt >> slzsk >> hgysy >> qlpfj >> cao >> jijiubao >> baiyao >> superbaiyao >> boom >> dubiao >> atom_boom >> B >> juan1 >> my >> aircase >> diangun >> yulei >> zidan >> dbjs >> yinxue >> tjsww >> lingpaia >> lingpaib >> lingpai0 >> lingpai1 >> lingpai2 >> lingpai3 >> yumao >> honghua >> guhua >> juan2 >> juan3 >> fenshu >> n >> nn >> nnn >> nnnn >> nnnnn >> wrbsp >> dhwj >> dysls >> fnhl >> kfzx
		>> fang[0].defense >> fang[1].num >> fang[2].num >> fang[3].num >> fang[4].num >> fang[5].num >> yuyi >> a >> sex >> xiaohua_name >> gong[0].attack >> gong[1].num >> gong[2].num >> gong[3].num >> gong[4].num >> gong[5].num >> diaozhui1nn >> diaozhui2nn >> diaozhui3nn >> diaozhui1n >> diaozhui2n >> diaozhui3n >> gong[0].gongname >> fang[0].fangname >> diaozhui1name >> diaozhui2name >> diaozhui3name >> zyname
		>> pet[1].num;
}