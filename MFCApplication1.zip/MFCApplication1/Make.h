﻿#pragma once


// Make 对话框

class Make : public CDialogEx
{
	DECLARE_DYNAMIC(Make)

public:
	Make(CWnd* pParent = NULL);   // 标准构造函数
	virtual ~Make();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CString NewName;
	CString NewPassword;
	CString Again;
};
string Key(string);