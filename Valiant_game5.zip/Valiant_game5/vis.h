#pragma once
void Music(char*);
void NoMusic();

#include <windows.h>
#include <cstdio>
#include <ctime>
#include <cmath>
#include <cstring>
#include <algorithm>
#pragma comment(lib, "Msimg32.lib") 
#define M_PI		3.14159265358979323846
using namespace std;

void RotateAnyAngle(HDC hdcDest,int placex,int placey,int SrcWidth,int SrcHeight,HDC hdcSrc,int nXOriginSrc,int nYOriginSrc,float Angle,bool Middle,COLORREF clrBack,bool Trans = true);
void RotateAnyAngle(HDC hdcDest,POINT &place,POINT &WAH,HDC hdcSrc,int nXOriginSrc,int nYOriginSrc,float Angle,bool Middle,COLORREF clrBack,bool Trans = true);
void Out(int nXOriginDest,int nYOriginDest,HFONT hf,COLORREF crTransparent,const char* wanna_char,COLORREF crBack=NULL,int t=1200,int b=720);
float Get_FPS();



typedef class bmpx
{
	static BLENDFUNCTION bf;

	RECT re;
	short place;
	HBITMAP Bmp;
	int Height,Width;
	int bTrans;

	bool Trans_Mode;

public:

	bmpx();
	bmpx(int width,int height);
	bmpx(const char* File_Name,int l=0,int r=0,int t=0,int b=0);
	~bmpx();

	void Change_Bmp(const char* File_Name);
	void Put_Bmp(const char* File_Name,int l = 0,int r = 0,int t = 0,int b = 0);

	inline void SetTransMode(bool Mode);
	inline void SetbTrans(int btrans);

	void Print_Bmp(int x,int y);

	void Print_Bmp(int x,int y,COLORREF clrBack,float multiple = 1);
	void Print_Bmp(int x,int y,COLORREF clrBack,float Angle,bool Middle_Mode);

	void Alpha_Print_Bmp(int x,int y,COLORREF clrBack,float multiple = 1);
	void Alpha_Print_Bmp(int x,int y,COLORREF clrBack,float Angle,bool Middle_Mode);

	inline HBITMAP GetBitmap() const;
	inline int GetHeight() const;
	inline int GetWidth() const;
	inline int GetbTrans() const;
	inline bool GetTransMode() const;

	//bool check();
}Bmpx;

class Button
{
	Bmpx picture;
	string name;
	bool type;
	HFONT hf;
	COLORREF crTransparent;
	COLORREF crBack;
	RECT place;

public:

	int to;
	bool now;

	Button(const char* Name,int l,int t,int r,int b,HFONT h=NULL,COLORREF crT = RGB(0,0,0),COLORREF crB = RGB(255,255,255));
	Button(const char* File_Name,int x ,int y,int l = 0,int r = 0,int t = 0,int b = 0 );

	void Show();
	bool Check();
	void Delete();
};