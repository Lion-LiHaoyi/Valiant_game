#include "stdafx.h"
#include "vis.h"
#include <windows.h>
#include <stdio.h>
#include <mmsystem.h>
#include <shellapi.h>
#pragma comment(lib,"winmm.lib")
UINT DeviceID;
void Music(char* a)
{
	char str[128] = { 0 };
	int i = 0;
	char buf[128] = { 0 };

	MCI_OPEN_PARMS mciOpen;
	MCIERROR mciError;
	mciOpen.lpstrDeviceType = "mpegvideo";
	mciOpen.lpstrElementName = a;
	mciError = mciSendCommand(0,MCI_OPEN,MCI_OPEN_TYPE | MCI_OPEN_ELEMENT,(DWORD)&mciOpen);
	if(mciError)
	{
		return;
	}
	DeviceID = mciOpen.wDeviceID;
	MCI_PLAY_PARMS mciPlay;

	mciError = mciSendCommand(DeviceID,MCI_PLAY,0,(DWORD)&mciPlay);
	if(mciError)
	{
		return;
	}
	return;
}

void NoMusic()
{
	MCI_GENERIC_PARMS mcistop;
	mciSendCommand(MCI_ALL_DEVICE_ID,MCI_CLOSE,MCI_WAIT,(DWORD)(LPMCI_GENERIC_PARMS)&mcistop);
}


void RotateAnyAngle(HDC hdcDest,int placex,int placey,int SrcWidth,int SrcHeight,HDC hdcSrc,int nXOriginSrc,int nYOriginSrc,float Angle,bool Middle,COLORREF clrBack,bool Trans)
{
	if(!Angle)
	{
		if(Trans) TransparentBlt(hdcDest,placex,placey,SrcWidth,SrcHeight,hdcSrc,0,0,SrcWidth,SrcHeight,clrBack);
		else BitBlt(hdcDest,placex,placey,SrcWidth,SrcHeight,hdcSrc,0,0,SRCCOPY);

		return;
	}

	HDC destDC = CreateCompatibleDC(NULL);

	float cosine = (float)cos(Angle / 180 * M_PI);
	float sine = (float)sin(Angle / 180 * M_PI);
	int x1 = (int)(SrcHeight * sine);
	int y1 = (int)(SrcHeight * cosine);
	int x2 = (int)(SrcWidth * cosine + SrcHeight * sine);
	int y2 = (int)(SrcHeight * cosine - SrcWidth * sine);
	int x3 = (int)(SrcWidth * cosine);
	int y3 = (int)(-SrcWidth * sine);
	int minx = min(0,min(x1,min(x2,x3)));
	int miny = min(0,min(y1,min(y2,y3)));
	int maxx = max(0,max(x1,max(x2,x3)));
	int maxy = max(0,max(y1,max(y2,y3)));
	int w = maxx - minx;
	int h = maxy - miny;

	if(Middle)
	{
		placex -= (w - SrcWidth) / 2;  placey -= (h - SrcHeight) / 2;
	}

	HBITMAP hbmResult = CreateCompatibleBitmap(GetDC(NULL),w,h);
	HBITMAP hbmOldDest = (HBITMAP)::SelectObject(destDC,hbmResult);

	if(clrBack != RGB(0,0,0))
	{
		HBRUSH hbrBack = CreateSolidBrush(clrBack);
		HBRUSH hbrOld = (HBRUSH)::SelectObject(destDC,hbrBack);
		PatBlt(destDC,0,0,w,h,PATCOPY);

		DeleteObject(::SelectObject(destDC,hbrOld));
		DeleteObject(hbrBack);
		DeleteObject(hbrOld);
	}

	SetGraphicsMode(destDC,GM_ADVANCED);
	XFORM xform;
	xform.eM11 = cosine;
	xform.eM12 = -sine;
	xform.eM21 = sine;
	xform.eM22 = cosine;
	xform.eDx = (float)-minx;
	xform.eDy = (float)-miny;
	SetWorldTransform(destDC,&xform);

	BitBlt(destDC,0,0,SrcWidth,SrcHeight,hdcSrc,0,0,SRCCOPY);

	DeleteObject(hbmOldDest);
	DeleteObject(destDC);

	SelectObject(hdcSrc,hbmResult);
	DeleteObject(hbmResult);

	if(Trans) TransparentBlt(hdcDest,placex,placey,w,h,hdcSrc,0,0,w,h,clrBack);
	else BitBlt(hdcDest,placex,placey,w,h,hdcSrc,0,0,SRCCOPY);
}

void RotateAnyAngle(HDC hdcDest,POINT &place,POINT &WAH,HDC hdcSrc,int nXOriginSrc,int nYOriginSrc,float Angle,bool Middle,COLORREF clrBack,bool Trans)
{
	if(!Angle)
	{
		if(Trans) TransparentBlt(hdcDest,place.x,place.y,WAH.x,WAH.y,hdcSrc,0,0,WAH.x,WAH.y,clrBack);
		else BitBlt(hdcDest,place.x,place.y,WAH.x,WAH.y,hdcSrc,0,0,SRCCOPY);

		return;
	}

	HDC destDC = CreateCompatibleDC(NULL);

	float cosine = (float)cos(Angle / 180 * M_PI);
	float sine = (float)sin(Angle / 180 * M_PI);
	int x1 = (int)(WAH.y * sine);
	int y1 = (int)(WAH.y * cosine);
	int x2 = (int)(WAH.x * cosine + WAH.y * sine);
	int y2 = (int)(WAH.y * cosine - WAH.x * sine);
	int x3 = (int)(WAH.x * cosine);
	int y3 = (int)(-WAH.x * sine);
	int minx = min(0,min(x1,min(x2,x3)));
	int miny = min(0,min(y1,min(y2,y3)));
	int maxx = max(0,max(x1,max(x2,x3)));
	int maxy = max(0,max(y1,max(y2,y3)));
	int w = maxx - minx;
	int h = maxy - miny;

	if(Middle)
	{
		place.x -= (w - WAH.x) / 2;  place.y -= (h - WAH.y) / 2;
	}

	HBITMAP hbmResult = CreateCompatibleBitmap(GetDC(NULL),w,h);
	HBITMAP hbmOldDest = (HBITMAP)::SelectObject(destDC,hbmResult);

	if(clrBack != RGB(0,0,0))
	{
		HBRUSH hbrBack = CreateSolidBrush(clrBack);
		HBRUSH hbrOld = (HBRUSH)::SelectObject(destDC,hbrBack);
		PatBlt(destDC,0,0,w,h,PATCOPY);

		DeleteObject(::SelectObject(destDC,hbrOld));
		DeleteObject(hbrBack);
		DeleteObject(hbrOld);
	}

	SetGraphicsMode(destDC,GM_ADVANCED);
	XFORM xform;
	xform.eM11 = cosine;
	xform.eM12 = -sine;
	xform.eM21 = sine;
	xform.eM22 = cosine;
	xform.eDx = (float)-minx;
	xform.eDy = (float)-miny;
	SetWorldTransform(destDC,&xform);

	BitBlt(destDC,0,0,WAH.x,WAH.y,hdcSrc,0,0,SRCCOPY);

	WAH.x = w; WAH.y = h;

	DeleteObject(hbmOldDest);
	DeleteObject(destDC);

	SelectObject(hdcSrc,hbmResult);
	DeleteObject(hbmResult);

	if(Trans) TransparentBlt(hdcDest,0,0,w,h,hdcSrc,0,0,w,h,clrBack);
	else BitBlt(hdcDest,0,0,w,h,hdcSrc,0,0,SRCCOPY);
}



float Get_FPS()
{
	static float  fps = 0;
	static int    frameCount = 0;
	static float  currentTime = 0.0f;
	static float  lastTime = 0.0f;

	frameCount++;
	currentTime = clock()*0.001f;

	if(currentTime - lastTime > 1.0f)
	{
		fps = (float)frameCount / (currentTime - lastTime);
		lastTime = currentTime;
		frameCount = 0;
	}

	return fps;
}
