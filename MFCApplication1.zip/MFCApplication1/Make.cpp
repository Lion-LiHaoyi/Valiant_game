﻿// Make.cpp : 实现文件
//

#include "stdafx.h"
#include "MFCApplication1.h"
#include "Make.h"
#include "afxdialogex.h"


// Make 对话框

IMPLEMENT_DYNAMIC(Make,CDialogEx)

Make::Make(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1,pParent)
	,NewName(_T(""))
	,NewPassword(_T(""))
	,Again(_T(""))
{

}

Make::~Make()
{
}

void Make::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX,IDC_NewName,NewName);
	DDX_Text(pDX,IDC_NewPassword,NewPassword);
	DDX_Text(pDX,IDC_Again,Again);
}


BEGIN_MESSAGE_MAP(Make,CDialogEx)
	ON_BN_CLICKED(IDOK,&Make::OnBnClickedOk)
END_MESSAGE_MAP()


// Make 消息处理程序


void Make::OnBnClickedOk()
{
	UpdateData(true);
	if(Again == NewPassword)
	{
		USES_CONVERSION;
		string name = W2A(NewName.LockBuffer());
		NewName.UnlockBuffer();
		string password = W2A(NewPassword.LockBuffer());
		NewPassword.UnlockBuffer();
		char buf[100],buf2[100];
		sprintf_s(buf2,"D:\\Valiant_game\\%s",name.c_str());
		CString   strFolderPath;
		strFolderPath = A2T("D:\\Valiant_game");
			//   判断路径是否存在   
		if(!PathIsDirectory((LPCTSTR)strFolderPath))
		{
			CreateDirectory((LPCTSTR)strFolderPath,NULL);
		}
		strFolderPath = A2T(buf2);
		if(!PathIsDirectory((LPCTSTR)strFolderPath))
		{
			CreateDirectory((LPCTSTR)strFolderPath,NULL);
		}
		else
		{
			MessageBox(_T("此用户已注册"),_T("错误"),MB_OK);
			goto f1;
		}
		sprintf_s(buf,"D:\\Valiant_game\\%s\\Password",name.c_str());
		ofstream fout(buf);
		password = Key(password);
		fout << password;
		strFolderPath = A2T("C:\\TDDownload");
		if(!PathIsDirectory((LPCTSTR)strFolderPath))
		{
			CreateDirectory((LPCTSTR)strFolderPath,NULL);
		}
		strFolderPath = A2T("C:\\TDDownload\\Valiant_game");
		if(!PathIsDirectory((LPCTSTR)strFolderPath))
		{
			CreateDirectory((LPCTSTR)strFolderPath,NULL);
		}
		sprintf_s(buf2,"C:\\TDDownload\\Valiant_game\\%s",name.c_str());
		strFolderPath = A2T(buf2);
		if(!PathIsDirectory((LPCTSTR)strFolderPath))
		{
			CreateDirectory((LPCTSTR)strFolderPath,NULL);
		}
		sprintf_s(buf,"C:\\TDDownload\\Valiant_game\\%s\\Password",name.c_str());
		ofstream fout1(buf);
		fout1 << password;
	}
	else
	{
		MessageBox(_T("确认密码错误"),_T("错误"),MB_OK);
	}
	// TODO: 在此添加控件通知处理程序代码
f1:
	CDialogEx::OnOK();
}
