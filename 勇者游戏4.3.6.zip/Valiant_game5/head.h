﻿#pragma once
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cstring>
#include <conio.h>
#include <string>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <windows.h>
#include <iostream>
#include <random>
#include <list>
using namespace std;
SYSTEMTIME Time;
class Player {
public:
	string name;
	int attack;
	int defense;
	int health;
	int mp;
	int max_health;
	int max_mp;
	int level;
	int exp;
	int range_exp;
	int max_exp;
	int air;
	int max_air;
	int miss;
	int max_miss;
}
tank = { "坦克",45,75,250,80,250,80,1,0,0,100,15,15,0,5 },
army = { "战士",60,55,150,100,150,100,1,0,0,100,20,20,10,10 },
ack = { "刺客",90,30,100,100,100,100,1,0,0,100,20,20,10,15 },
mag = { "法师",75,40,120,250,120,250,1,0,0,100,25,25,10,10 },
gun = { "射手",80,35,110,150,110,150,1,0,0,100,20,20,10,30 },
player = { "\0",0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
class Enemy { //怪的结构体,并初始化各种怪
public:
	string name;
	string wupin;
	int attack;
	int defense;
	int health;
	int max_health;
	int money;
	int exp;
	int wupin_sign;
	int wupinpro;
	int double_attack;
	int miss;
}
strongman = { "森林巨人","黄金圣衣",50,60,600,600,200,100,1,2,5,1 },
witch = { "森林女巫","银甲",30,45,100,100,50,50,2,3,0,0 },
xiyi = { "森林蜥蜴","铁甲",12,30,80,80,30,35,3,4,0,0 },
big_strongman = { "森林巨人王","程序猿令牌上半部分",150,180,1200,1200,800,400,4,10,2,1 },
lions = { "草原狮群","程序猿令牌下半部分",120,150,1400,1400,800,400,26,24,10,1 },
lion = { "草原雄狮","绝世好剑",100,100,400,400,200,100,5,2,5,1 },
horse = { "草原野马","碧血剑",70,20,200,120,50,50,6,3,0,0 },
bee = { "草原黄蜂","长剑",23,10,75,75,30,35,7,4,2,1 },
stone = { "山脉岩石","布衣",15,50,100,100,50,20,0,5,0,0 },
asshole = { "山脉菊花","匕首",20,10,60,60,50,20,8,5,0,0 },
cxy = { "程序猿","程序猿吊坠",100,200,1500,1500,500,300,17,5,5,1 },
shitu = { "程序廖","草泥马令牌",450,240,1800,1800,600,500,9,10,10,2 },
wugui = { "巨龟","神龟之盾",40,375,1660,1660,150,100,11,1,2,0 },
shark = { "虎鲨","狂鲨利齿",90,50,500,500,300,150,10,1,5,0 },
wuzei = { "大王乌贼","乌贼墨胆",100,200,1500,1500,200,100,24,10,7,1 },
lj = { "蓝鲸","鲸骨",70,270,2000,2000,200,200,23,10,10,1 },
bigshark = { "巨兽鲨","鲨鳍",150,150,1000,1000,200,200,22,10,10,1 },
sly = { "圣灵鱼","圣殿信物",1,1,1,1,1,1,25,10,0,4 },
Bman = { "B_boom投手","B_boom",6666,60,300,300,300,200,12,1,0,0 },
fashu = { "法妖","魔法卷轴",150,20,250,250,300,200,13,8,2,1 },
hongshi = { "猩红之石","猩红精华",100,100,500,500,100,100,20,8,0,0 },
gushi = { "远古之石","远古精华",100,100,500,500,100,100,21,8,0,0 },
ccm = { "草泥马","草泥马吊坠",200,100,750,750,300,200,18,5,5,1 },
cnx = { "草泥爔","法克鱿令牌",650,180,1500,1500,800,700,14,10,10,2 },
ffk = { "法克鱿","法克鱿吊坠",100,300,700,700,300,300,19,5,5,1 },
fky = { "法克逸","舟凯学长令牌",550,300,1800,1800,800,700,15,10,10,2 },
dog = { "单身狗","圣殿信物",125,125,520,520,500,300,25,5,0,0 },
butterfly = { "雅蠛蝶","\0",30,10,50,50,20,20,25,0,0,3 },
jinying = { "社会金鹰","羽毛",200,100,200,200,200,100,27,7,5,2 },
zk = { "舟凯学长","\0",700,500,2100,2100,1000,1000,16,0,12,2 },
hzwer = { "hzwer","\0",1000,600,2500,2500,2000,2000,16,0,15,3 },
duxiu = { "陈独秀","独秀の奖杯",66,66,233,233,150,100,28,2,9,1 },
guai = { "\0","\0",0,0,0,0,0,0,0,0,0 };
class Pet {
public:
	int attack;
	int defense;
	int health;
	string name;
	int num;
}
pet[10] = { { 0,0,0,"无",0 },{ 66,66,233,"陈独秀",1 } };
class Place {
public:
	int bar, hotel, forest1, forest2, forest3, grass1, grass2, grass3, mountain, mlgb, sea, mesh, fsyg, cnm, fky, jd, zysd;
}
place = { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17 };
class Attack {
public:
	string gongname;
	int attack;
	int num;
}
gong[6] = { { "无",0 },{ "匕首",8 },{ "长剑",15 },{ "碧血剑",25 },{ "绝世好剑",60 },{ "狂鲨利齿",80 } };
class Defense {
public:
	string fangname;
	int defense;
	int num;
}
fang[6] = { { "无",0 },{ "布衣",10 },{ "铁甲",20 },{ "银甲",40 },{ "黄金圣衣",80 },{ "神龟之盾",100 } };
string say[6] = { "真正绑架校花的不是舟凯！","社会金鹰掉落的位置可以是末路之地！","竞技场的对手可以掉落任何东西！",
"海底有一条通往胜利的捷径！","在春天通关比其他时候更难（滑稽）","作者无外挂通关要30分钟，你能更快吗？"
}, sex;
int max_exp = 0, me = 0, doing = 0, c1, c2;
int choose_number = 0, s = 0, battle = 0, money = 1000, bi = 0, yun = 0, place_sign = 0, jishu = 0, jishu2 = 20, jishu3 = 1, huolianjishu = 4;
int wzmd = 0, jg = 0, sdxw = 0, sq = 0, res, yumao = 0, yuyi = 0, a, ming = 0;
int bbcy = 0, bbcyn = 100, pkzr = 0, pkzrn = 125, zhhc = 0, zhhcn = 175, dltxz = 0, dltxzn = 135, cqmsb = 0, cqmsbn = 150;
int wgbxs = 0, wgbxsn = 175, slgmt = 0, slgmtn = 120, slzsk = 0, slzskn = 75, hgysy = 0, hgysyn = 200, qlpfj = 0, qlpfjn = 75;
int cao = 4, jijiubao = 3, baiyao = 3, superbaiyao = 1, boom = 4, dubiao = 3, atom_boom = 1, B = 0, juan1 = 0, my = 3, aircase = 1, diangun = 1, yulei = 1, zidan = 1;
int dbjs = 0, yinxue = 0, tjsww = 0, lingpaia = 0, lingpaib = 0, lingpai0 = 0, lingpai1 = 0, lingpai2 = 0, lingpai3 = 0;
int honghua = 0, guhua = 0, juan2 = 0, juan3 = 0, fenshu = 0, n = 0, nn = 0, nnn = 0, nnnn = 0, nnnnn = 0, wrbsp = 0, dhwj = 0, dysls = 0, fnhl = 0, kfzx = 0;
int diaozhui1nn = 0, diaozhui2nn = 0, diaozhui3nn = 0, diaozhui1n = 0, diaozhui1 = 200, diaozhui2n = 0, diaozhui2 = 50, diaozhui3n = 0, diaozhui3 = 70;
string diaozhui1name = "无", diaozhui2name = "无", diaozhui3name = "无", zyname = "无", xiaohua_name, key;
char buf[100],buf2[100];
int p[75][150][2];
void AddWupin(int);
int AttackResult();
void BattleAct();
void ChooseWupin();
void DisplayState();
void OrdinaryAct();
int SuiJi();
void Save();
void Open();
void MapForforest();
int SuiJi100();
void WhetherLevelUp();
void Setjindutiao(int);
void MapForsea();
void SlowDisplay(char *,int a = 60);
void MapForgrass();
void zhuangbei();
void Map();
void gotoxy(int, int);
void menu();
void MapFordangerous();
void MapForpeople();
void Boom();
void eatline();
void battlepre();
void ColorEgg();
void Color(int);
int GetPoint();
void Pet();
string password(string);